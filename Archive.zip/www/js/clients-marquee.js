(function () {
  const LOGO_COUNT = 8;

  function buildLogoGroup() {
    const logo =
      '<div class="client-logo media-placeholder" data-i18n="clients.logo3">Client logo</div>';
    const logos = logo.repeat(LOGO_COUNT);
    return (
      `<div class="clients-marquee__group">${logos}</div>` +
      `<div class="clients-marquee__group" aria-hidden="true">${logos}</div>`
    );
  }

  function buildRow(rowClass) {
    return (
      `<div class="clients-marquee ${rowClass}">` +
      `<div class="clients-marquee__track">${buildLogoGroup()}</div>` +
      `</div>`
    );
  }

  function buildClientsSection() {
    return (
      `<section class="section clients clients--marquee" id="clients" aria-labelledby="clients-heading">` +
      `<p class="section-label" data-i18n="clients.label">Trusted by</p>` +
      `<h2 class="sr-only" id="clients-heading">Trusted by</h2>` +
      `<div class="clients-marquee-stack reveal">` +
      buildRow('clients-marquee--row-1') +
      buildRow('clients-marquee--row-2') +
      buildRow('clients-marquee--row-3') +
      `</div>` +
      `</section>`
    );
  }

  function initClientsMarquee() {
    const mounts = document.querySelectorAll('[data-include-clients-marquee]');
    if (!mounts.length) return;
    mounts.forEach((mount) => {
      mount.outerHTML = buildClientsSection();
    });
  }

  function onReady() {
    initClientsMarquee();
  }

  if (document.querySelector('[data-include-clients-marquee]')) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', onReady, { once: true });
    } else {
      onReady();
    }
  }
})();
