(function () {
  const STORAGE_KEY = 'lisenbart-lang';
  const DEFAULT_LANG = 'en';
  const SUPPORTED = ['en', 'pl', 'ua'];
  const LANG_CHOICES = [
    { value: 'en', label: '🇬🇧 EN' },
    { value: 'pl', label: '🇵🇱 PL' },
    { value: 'ua', label: '🇺🇦 UA' },
  ];

  let strings = {};
  let currentLang = DEFAULT_LANG;

  function getNested(obj, path) {
    return path.split('.').reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : null), obj);
  }

  function detectLang() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved && SUPPORTED.includes(saved)) return saved;

    const prefs = navigator.languages?.length ? navigator.languages : [navigator.language];
    for (const raw of prefs) {
      if (!raw) continue;
      const code = raw.toLowerCase().split('-')[0];
      if (code === 'pl') return 'pl';
      if (code === 'uk' || code === 'ua') return 'ua';
      if (code === 'en') return 'en';
    }
    return DEFAULT_LANG;
  }

  async function fetchLangFile(lang) {
    const res = await fetch(`lang/${lang}.json`, { cache: 'default' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  async function loadLangData(lang) {
    try {
      strings = await fetchLangFile(lang);
    } catch (err) {
      const bundle = window.LISENBART_I18N;
      if (bundle?.[lang]) {
        strings = bundle[lang];
      } else if (bundle?.[DEFAULT_LANG]) {
        strings = bundle[DEFAULT_LANG];
        lang = DEFAULT_LANG;
      } else if (lang !== DEFAULT_LANG) {
        try {
          strings = await fetchLangFile(DEFAULT_LANG);
          lang = DEFAULT_LANG;
        } catch {
          throw err;
        }
      } else {
        throw err;
      }
    }
    currentLang = lang;
    document.documentElement.lang = lang === 'ua' ? 'uk' : lang;
  }

  function markReady() {
    document.documentElement.classList.remove('is-i18n-loading');
    document.documentElement.classList.add('is-i18n-ready');
    window.dispatchEvent(new CustomEvent('lisenbart:ready'));
  }

  function applyTranslations() {
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      if (el.closest('.lang-select')) return;
      const key = el.getAttribute('data-i18n');
      const value = getNested(strings, key);
      if (value == null || typeof value === 'object') return;
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        el.placeholder = value;
      } else {
        el.textContent = value;
      }
    });

    document.querySelectorAll('[data-i18n-html]').forEach((el) => {
      const key = el.getAttribute('data-i18n-html');
      const value = getNested(strings, key);
      if (value != null) el.innerHTML = value;
    });

    document.querySelectorAll('option[data-i18n]').forEach((opt) => {
      const key = opt.getAttribute('data-i18n');
      const value = getNested(strings, key);
      if (value != null) opt.textContent = value;
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
      const key = el.getAttribute('data-i18n-placeholder');
      const value = getNested(strings, key);
      if (value != null) el.placeholder = value;
    });

    const titleKey = document.body.getAttribute('data-title-key');
    const pageTitle = titleKey ? getNested(strings, titleKey) : null;
    if (pageTitle) document.title = pageTitle;
    else if (strings.meta?.title) document.title = strings.meta.title;

    const metaDesc = document.querySelector('meta[name="description"]');
    const descKey = document.body.getAttribute('data-meta-desc-key');
    const pageDescription = descKey ? getNested(strings, descKey) : null;
    if (metaDesc) {
      if (pageDescription) metaDesc.setAttribute('content', pageDescription);
      else if (strings.meta?.description) metaDesc.setAttribute('content', strings.meta.description);
    }

    const label = getNested(strings, 'langSelect.label') || 'Language';
    document.querySelectorAll('.lang-select').forEach((sel) => {
      sel.value = currentLang;
      sel.setAttribute('aria-label', label);
    });
  }

  async function setLang(lang, { persist = true } = {}) {
    if (!SUPPORTED.includes(lang)) return;
    await loadLangData(lang);
    if (persist) localStorage.setItem(STORAGE_KEY, lang);
    applyTranslations();
    window.dispatchEvent(new CustomEvent('langchange', { detail: { lang } }));
  }

  function populateLangSelects() {
    document.querySelectorAll('.lang-select').forEach((sel) => {
      sel.replaceChildren();
      LANG_CHOICES.forEach(({ value, label }) => {
        const opt = document.createElement('option');
        opt.value = value;
        opt.textContent = label;
        sel.appendChild(opt);
      });
    });
  }

  function bindLangSelects() {
    document.querySelectorAll('.lang-select').forEach((sel) => {
      sel.addEventListener('change', () => {
        void setLang(sel.value, { persist: true });
      });
    });
  }

  async function init() {
    try {
      populateLangSelects();
      const lang = detectLang();
      await setLang(lang, { persist: false });
      bindLangSelects();
    } catch (err) {
      console.error('LISENBART i18n init failed:', err);
    } finally {
      markReady();
    }
  }

  window.LisenbartI18n = {
    setLang: (lang) => setLang(lang, { persist: true }),
    getLang: () => currentLang,
    getStrings: () => strings,
    applyTranslations,
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      void init();
    });
  } else {
    void init();
  }
})();
