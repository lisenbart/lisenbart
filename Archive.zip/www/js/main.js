(function () {
  const header = document.querySelector('.site-header');
  const navToggle = document.querySelector('.nav-toggle');
  const mobileNav = document.querySelector('.mobile-nav');
  const mobileClose = document.querySelector('.mobile-nav__close');
  const cursor = document.querySelector('.cursor-dot');

  /* Nav scroll state */
  function onScroll() {
    if (!header) return;
    header.classList.toggle('is-scrolled', window.scrollY > 100);
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  if (!document.querySelector('.hero') && header) {
    header.classList.add('is-scrolled');
  }

  /* Mobile menu */
  function setMenuOpen(open) {
    if (!mobileNav) return;
    mobileNav.classList.toggle('is-open', open);
    mobileNav.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.style.overflow = open ? 'hidden' : '';
    if (navToggle) navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  navToggle?.addEventListener('click', () => setMenuOpen(true));
  mobileClose?.addEventListener('click', () => setMenuOpen(false));
  mobileNav?.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => setMenuOpen(false));
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mobileNav?.classList.contains('is-open')) {
      setMenuOpen(false);
    }
  });

  /* Reveal on scroll */
  function initReveal() {
    const revealEls = document.querySelectorAll('.reveal:not(.is-visible)');
    if (!revealEls.length) return;

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      revealEls.forEach((el) => el.classList.add('is-visible'));
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );
    revealEls.forEach((el, i) => {
      el.style.transitionDelay = `${(i % 6) * 0.08}s`;
      io.observe(el);
    });
  }

  initReveal();
  window.addEventListener('lisenbart:ready', initReveal);

  /* Hero stats — single line, scale to container width */
  function fitHeroStatsLine() {
    const line = document.querySelector('.hero__meta .hero-stats');
    if (!line) return;

    const container = line.parentElement;
    if (!container) return;

    const maxPx = window.matchMedia('(max-width: 768px)').matches ? 14 : 17;
    const minPx = 8;
    let size = maxPx;

    line.style.fontSize = `${size}px`;

    const available = container.clientWidth;
    while (line.scrollWidth > available && size > minPx) {
      size -= 0.5;
      line.style.fontSize = `${size}px`;
    }
  }

  let heroStatsRaf = null;
  function scheduleHeroStatsFit() {
    if (heroStatsRaf) cancelAnimationFrame(heroStatsRaf);
    heroStatsRaf = requestAnimationFrame(() => {
      heroStatsRaf = null;
      fitHeroStatsLine();
    });
  }

  if (document.querySelector('.hero__meta .hero-stats')) {
    scheduleHeroStatsFit();
    window.addEventListener('resize', scheduleHeroStatsFit, { passive: true });
    window.addEventListener('lisenbart:ready', scheduleHeroStatsFit);
    window.addEventListener('langchange', scheduleHeroStatsFit);
  }

  /* Portfolio card hover accent */
  document.querySelectorAll('.work-card').forEach((card) => {
    card.addEventListener('mouseenter', () => card.classList.add('is-hovered'));
    card.addEventListener('mouseleave', () => card.classList.remove('is-hovered'));
  });

  /* Custom cursor */
  if (cursor && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
    document.body.classList.add('has-custom-cursor');
    document.querySelectorAll('.lang-select').forEach((el) => {
      el.style.cursor = 'pointer';
    });
    let x = 0;
    let y = 0;
    let cursorTicking = false;
    window.addEventListener(
      'mousemove',
      (e) => {
        x = e.clientX;
        y = e.clientY;
        if (cursorTicking) return;
        cursorTicking = true;
        requestAnimationFrame(() => {
          cursor.style.left = `${x}px`;
          cursor.style.top = `${y}px`;
          cursorTicking = false;
        });
      },
      { passive: true }
    );
    document.querySelectorAll('.work-card, .door-card, .ip-card, a, button').forEach((el) => {
      el.addEventListener('mouseenter', () => cursor.classList.add('is-large'));
      el.addEventListener('mouseleave', () => cursor.classList.remove('is-large'));
    });
  }

  /* Contact forms */
  function getContactMessages() {
    const strings = window.LisenbartI18n?.getStrings?.() || {};
    return {
      success: strings.contact?.success || 'Thank you — we received your message and will get back to you within 24 hours.',
      error: strings.contact?.error || 'Something went wrong. Please email us directly at info@lisenbart.com.',
    };
  }

  function showFormFeedback(feedback, type) {
    if (!feedback) return;
    const { success, error } = getContactMessages();
    feedback.textContent = type === 'success' ? success : error;
    feedback.className = `form-feedback is-${type}`;
  }

  const CONTACT_SUBJECT_LABELS = {
    home: 'Homepage',
    original: 'Original Worlds',
    services: 'Commercial Animation',
  };

  function prepareContactFormPayload(form) {
    const emailInput = form.querySelector('[name="email"]');
    const email = emailInput?.value.trim() || '';
    const source = form.querySelector('[name="source"]')?.value || 'home';
    const label = CONTACT_SUBJECT_LABELS[source] || 'Inquiry';

    const subjectField = form.querySelector('[name="_subject"]');
    if (subjectField) {
      subjectField.value = email
        ? `LISENBART — ${label} — ${email}`
        : `LISENBART — ${label}`;
    }

    const replyToField = form.querySelector('[name="_replyto"]');
    if (replyToField) replyToField.value = email;

    const pageUrlField = form.querySelector('[name="page_url"]');
    if (pageUrlField) pageUrlField.value = window.location.href;
  }

  document.querySelectorAll('.contact-form').forEach((form) => {
    const feedback = form.querySelector('.form-feedback');
    prepareContactFormPayload(form);

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const honeypot = form.querySelector('[name="_gotcha"]');
      if (honeypot?.value) return;

      const email = form.querySelector('[name="email"]');
      if (!email?.value || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
        showFormFeedback(feedback, 'error');
        return;
      }

      const message = form.querySelector('[name="message"]');
      if (!message?.value.trim()) {
        showFormFeedback(feedback, 'error');
        return;
      }

      prepareContactFormPayload(form);

      /* Formspree: set form.action = 'https://formspree.io/f/XXXX' then form.submit() */
      showFormFeedback(feedback, 'success');
      form.reset();
      prepareContactFormPayload(form);
    });
  });

  window.addEventListener('langchange', () => {
    document.querySelectorAll('.form-feedback').forEach((feedback) => {
      if (feedback.classList.contains('is-success')) showFormFeedback(feedback, 'success');
      else if (feedback.classList.contains('is-error')) showFormFeedback(feedback, 'error');
    });
  });

  initHeroVideoFit();

  function initHeroVideoFit() {
    const hero = document.querySelector('.hero');
    const stage = hero?.querySelector('.hero__stage');
    const media = hero?.querySelector('.hero__media');
    const videoWrap = hero?.querySelector('.hero__video');
    const iframe = hero?.querySelector('.hero__video iframe');
    if (!hero || !stage || !media || !videoWrap || !iframe) return;

    const VIDEO_RATIO = 16 / 9;

    function fitHeroVideo() {
      const w = stage.clientWidth;
      if (!w) return;

      const videoHeight = w / VIDEO_RATIO;
      const maxHeight = window.innerHeight;
      const containerHeight = Math.min(videoHeight, maxHeight);

      stage.style.height = `${containerHeight}px`;
      media.style.height = `${containerHeight}px`;
      videoWrap.style.height = `${containerHeight}px`;

      iframe.style.width = '100%';
      iframe.style.height = `${videoHeight}px`;
      iframe.style.top = '0';
      iframe.style.left = '0';
      iframe.style.transform = 'none';
    }

    fitHeroVideo();
    iframe.addEventListener('load', fitHeroVideo);

    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(fitHeroVideo);
      ro.observe(stage);
    }

    window.addEventListener('resize', fitHeroVideo, { passive: true });
    if (window.visualViewport) {
      visualViewport.addEventListener('resize', fitHeroVideo, { passive: true });
    }
    window.addEventListener('orientationchange', () => {
      requestAnimationFrame(fitHeroVideo);
    });
  }

  function loadVimeoPlayerApi() {
    if (window.Vimeo?.Player) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const existing = document.querySelector('script[data-vimeo-player]');
      if (existing) {
        existing.addEventListener('load', () => resolve(), { once: true });
        existing.addEventListener('error', () => reject(new Error('Vimeo API failed')), { once: true });
        return;
      }
      const script = document.createElement('script');
      script.src = 'https://player.vimeo.com/api/player.js';
      script.defer = true;
      script.dataset.vimeoPlayer = '1';
      script.onload = () => resolve();
      script.onerror = () => reject(new Error('Vimeo API failed'));
      document.body.appendChild(script);
    });
  }

  function initHeroVimeo() {
    const iframe = document.querySelector('.hero__video iframe');
    const volumeWrap = document.querySelector('.hero__volume');
    const btn = volumeWrap?.querySelector('.hero__sound');
    const panel = document.getElementById('hero-volume-panel');
    const slider = document.getElementById('hero-volume-slider');
    const valueOut = volumeWrap?.querySelector('.hero__volume-value');
    if (!iframe || !btn || !panel || !slider || btn.dataset.soundReady === '1') return;

    const iconOff = btn.querySelector('.hero__sound-icon--off');
    const iconOn = btn.querySelector('.hero__sound-icon--on');
    let player = null;
    let volumePercent = 0;

    function applyAriaLabels() {
      const strings = window.LisenbartI18n?.getStrings?.() || {};
      const openLabel = strings.hero?.volumeOpen || 'Volume';
      const volLabel = strings.hero?.volume || 'Volume';
      btn.setAttribute('aria-label', openLabel);
      panel.setAttribute('aria-label', volLabel);
    }

    function updateVolumeUi() {
      const hasVolume = volumePercent > 0;
      slider.value = String(volumePercent);
      slider.setAttribute('aria-valuenow', String(volumePercent));
      if (valueOut) valueOut.textContent = `${volumePercent}%`;
      btn.classList.toggle('has-volume', hasVolume);
      iconOff?.classList.toggle('is-active', !hasVolume);
      iconOn?.classList.toggle('is-active', hasVolume);
    }

    function setPanelOpen(open) {
      panel.hidden = !open;
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    }

    async function applyVolume(percent) {
      volumePercent = Math.max(0, Math.min(100, Math.round(percent)));
      updateVolumeUi();
      if (!player) return;
      try {
        const level = volumePercent / 100;
        await player.setVolume(level);
        await player.setMuted(volumePercent === 0);
        if (volumePercent > 0) await player.play();
      } catch (err) {
        console.warn('Vimeo volume failed', err);
      }
    }

    function bindPlayer() {
      if (!window.Vimeo?.Player || btn.dataset.soundReady === '1') return;
      btn.dataset.soundReady = '1';
      player = new Vimeo.Player(iframe);
      updateVolumeUi();
      applyAriaLabels();

      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        setPanelOpen(panel.hidden);
      });

      slider.addEventListener('input', () => {
        void applyVolume(Number(slider.value));
      });

      panel.addEventListener('click', (e) => e.stopPropagation());

      document.addEventListener('click', (e) => {
        if (!volumeWrap.contains(e.target)) setPanelOpen(false);
      });

      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') setPanelOpen(false);
      });

      window.addEventListener('langchange', applyAriaLabels);
    }

    void loadVimeoPlayerApi()
      .then(bindPlayer)
      .catch((err) => console.warn(err.message));
  }

  initHeroVimeo();

  /* Active nav link for current page */
  const path = window.location.pathname;
  document.querySelectorAll('[data-nav]').forEach((link) => {
    const nav = link.getAttribute('data-nav');
    const isActive =
      (nav === 'work' && path.includes('work')) ||
      (nav === 'original' && path.includes('original')) ||
      (nav === 'partnership' && path.includes('partnership')) ||
      (nav === 'services' && path.includes('services'));
    link.classList.toggle('is-active', isActive);
  });
})();
