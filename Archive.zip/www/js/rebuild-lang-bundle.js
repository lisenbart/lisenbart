/** Run from www/: node js/rebuild-lang-bundle.js */
const fs = require('fs');
const path = require('path');

const langDir = path.join(__dirname, '..', 'lang');
const wwwDir = path.join(__dirname, '..');
const langs = ['en', 'pl', 'ua'];
const data = {};

/** Keys used by JS or body attrs, not data-i18n in static HTML */
const PROGRAMMATIC_KEYS = new Set([
  'meta.title',
  'meta.description',
  'langSelect.label',
  'original.pageTitle',
  'original.metaDescription',
  'services.pageTitle',
  'services.metaDescription',
  'partnership.pageTitle',
  'partnership.metaDescription',
  'notFound.title',
  'hero.volumeOpen',
  'contact.success',
  'contact.error',
  'clients.label',
  'clients.logo3',
]);

function getNested(obj, keyPath) {
  return keyPath.split('.').reduce((acc, key) => (acc && acc[key] !== undefined ? acc[key] : null), obj);
}

function collectKeys(obj, prefix = '') {
  return Object.entries(obj).flatMap(([key, value]) => {
    const full = prefix ? `${prefix}.${key}` : key;
    if (value && typeof value === 'object' && !Array.isArray(value)) return collectKeys(value, full);
    return [full];
  });
}

function normalizeText(text) {
  return text.replace(/\s+/g, ' ').trim();
}

function decodeHtmlEntities(text) {
  return text
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

for (const lang of langs) {
  data[lang] = JSON.parse(fs.readFileSync(path.join(langDir, `${lang}.json`), 'utf8'));
}

const enKeys = new Set(collectKeys(data.en));
for (const lang of langs.slice(1)) {
  const keys = new Set(collectKeys(data[lang]));
  const missing = [...enKeys].filter((key) => !keys.has(key));
  const extra = [...keys].filter((key) => !enKeys.has(key));
  if (missing.length || extra.length) {
    console.error(`Key mismatch (${lang}): missing ${missing.length}, extra ${extra.length}`);
    if (missing.length) console.error('  missing:', missing.join(', '));
    if (extra.length) console.error('  extra:', extra.join(', '));
    process.exit(1);
  }
}

const htmlFiles = ['index.html', 'original.html', 'partnership.html', 'services.html', '404.html'];
const usedKeys = new Set([...PROGRAMMATIC_KEYS]);
const fallbackMismatches = [];

for (const file of htmlFiles) {
  const html = fs.readFileSync(path.join(wwwDir, file), 'utf8');

  for (const match of html.matchAll(/data-i18n(?:-html|-placeholder)?="([^"]+)"/g)) {
    usedKeys.add(match[1]);
  }

  for (const match of html.matchAll(/data-(?:title|meta-desc)-key="([^"]+)"/g)) {
    usedKeys.add(match[1]);
  }

  for (const match of html.matchAll(/data-i18n="([^"]+)"[^>]*>([^<]*)</g)) {
    const key = match[1];
    const htmlText = normalizeText(decodeHtmlEntities(match[2]));
    const jsonText = getNested(data.en, key);
    if (typeof jsonText !== 'string' || !htmlText) continue;
    if (normalizeText(jsonText) !== htmlText) {
      fallbackMismatches.push({ file, key, html: htmlText, json: normalizeText(jsonText) });
    }
  }
}

const missingInEn = [...usedKeys].filter((key) => {
  const value = getNested(data.en, key);
  return value == null || typeof value === 'object';
});

if (missingInEn.length) {
  console.error('References missing EN keys:', missingInEn.join(', '));
  process.exit(1);
}

const orphaned = [...enKeys].filter((key) => !usedKeys.has(key));
if (orphaned.length) {
  console.error('Orphaned EN keys (not in HTML/JS):', orphaned.join(', '));
  process.exit(1);
}

if (fallbackMismatches.length) {
  console.error('HTML fallback text does not match en.json:');
  for (const { file, key, html, json } of fallbackMismatches) {
    console.error(`  ${file} [${key}]`);
    console.error(`    HTML: ${html}`);
    console.error(`    JSON: ${json}`);
  }
  process.exit(1);
}

fs.writeFileSync(
  path.join(langDir, 'bundle.js'),
  `window.LISENBART_I18N=${JSON.stringify(data)};\n`
);

console.log(`OK: ${enKeys.size} keys × ${langs.length} langs, ${usedKeys.size} refs. bundle.js updated.`);
