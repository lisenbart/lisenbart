Unnecessary Things — key art and optional preview.

  cover.webp (+ cover.jpg) — 16:9 cover
  preview.mp4 / preview.webm — optional hover loop
  poster.webp — optional

Site: original.html project card
