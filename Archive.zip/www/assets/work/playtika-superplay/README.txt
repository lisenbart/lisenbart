Playtika / SuperPlay — case visual.

  cover.webp (+ cover.jpg) — 16:9 cover
  preview.mp4 / preview.webm — optional

Site: services.html case card
