Optional local showreel (index hero currently uses Vimeo embed):

  reel.mp4      — H.264, ≤15 MB, 16:9
  reel.webm     — WebM version
  reel-poster.webp — poster frame

To use: replace iframe in index.html .hero__video with <video> (see assets/README.md).
