# Media for LISENBART.com

All site media lives in `www/assets/`. Code in `www/`, copy in `www/lang/`.

## Structure

```
assets/
├── hero/                 — optional local showreel (index uses Vimeo embed today)
├── work/                 — one folder per project or case
│   ├── unnecessary-things/
│   ├── playtika-superplay/
│   └── _incoming/        — temporary drop zone
├── clients/              — white SVG logos for dark background
└── brand/                — LISENBART logo, favicon, OG image (1200×630)
```

## Naming

- Latin **kebab-case**: `cover.webp`, `preview.mp4`
- No spaces or Cyrillic in filenames
- One project = one folder under `work/`

## Formats

| Type | Format | Notes |
|------|--------|-------|
| Covers | `.webp` (+ `.jpg` fallback) | 16:9, ~200 KB target |
| Logos | `.svg` | Monochrome white |
| Video | `.mp4` (H.264), optional `.webm` | Hero ≤ 15 MB; card previews ≤ 3 MB |
| Poster | `.webp` / `.jpg` | While video loads |

## Where files appear on site

| Folder | Used on |
|--------|---------|
| `hero/` | `index.html` hero (when switching from Vimeo to self-hosted) |
| `work/unnecessary-things/` | `original.html` — Unnecessary Things card |
| `work/playtika-superplay/` | `services.html` — Playtika / SuperPlay case |
| `clients/` | `index.html` — Trusted by row |
| `brand/` | favicon, OG, optional header logo |

## Standard files per project folder

| File | Required | Purpose |
|------|----------|---------|
| `cover.webp` | yes | 16:9 cover in grids |
| `cover.jpg` | no | `<picture>` fallback |
| `preview.mp4` | no | Short hover loop (muted) |
| `preview.webm` | no | WebM preview |
| `poster.webp` | no | Poster before video loads |

## Workflow

1. Drop raw files in `work/_incoming/` or the project folder.
2. Compress video (HandBrake / ffmpeg), export WebP covers.
3. Rename per table above.
4. Replace `.media-placeholder` blocks in HTML with `<picture>` / `<video>`.
5. After JSON edits: `node js/rebuild-lang-bundle.js`.

## HTML examples

```html
<picture>
  <source srcset="assets/work/unnecessary-things/cover.webp" type="image/webp">
  <img src="assets/work/unnecessary-things/cover.jpg" alt="Unnecessary Things" loading="lazy">
</picture>

<img src="assets/clients/playtika.svg" alt="Playtika" width="140" loading="lazy">
```

## Git

Large video is gitignored (see `www/.gitignore`). Commit folder structure and small SVG/WebP; keep video local or on the deploy server.
