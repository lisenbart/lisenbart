Логотипи клієнтів — білі SVG, прозорий фон.

Очікувані файли:
  playtika.svg
  superplay.svg

Додаткові: brand-slug.svg (латиниця, kebab-case)
