# LISENBART — Remove Homepage Stats Block Report

**Date:** 2026-05-28  
**Task:** Remove the separate KPI-style stats block from the homepage About section; keep proof facts inside About body text only.

---

## Files changed

| File | Change |
|------|--------|
| `www/index.html` | Removed `.about-stats` block (4 stat cards); added `about-grid--single` and `about-grid__body--multiline` on About body |
| `www/lang/en.json` | Updated `about.body` to approved multi-paragraph EN copy with embedded proof facts |
| `www/lang/pl.json` | Updated `about.body` to approved multi-paragraph PL copy with embedded proof facts |
| `www/lang/ua.json` | Updated `about.body` to approved multi-paragraph UA copy with embedded proof facts |
| `www/lang/bundle.js` | Rebuilt after JSON changes |
| `www/css/style.css` | Added `.about-grid__body--multiline` and `.about-grid--single` (homepage-only layout fix) |

---

## Stats block removal summary

**Removed from homepage (`index.html`):**
- Visible `.about-stats` container with four stat cards bound to `about.stat1`–`about.stat4`
- EN labels: Since 2006 / 1,000+ / 11 / Since 1991
- PL labels: Od 2006 / 1 000+ / 11 / Od 1991
- UA labels: З 2006 / 1 000+ / 11 / З 1991

**Not removed:**
- About section itself
- Proof facts (now in body text)
- Unused `about.stat1`–`about.stat4` keys in JSON (kept for key parity)
- `.about-stats` CSS rules (harmless; no longer referenced in HTML)

**No new stats/KPI block added elsewhere on the homepage.**

---

## About copy status (EN / PL / UA)

All three languages use the approved multi-paragraph About body with `\n\n` paragraph breaks. Proof facts are present in paragraph 3 of each version:

| Fact | EN | PL | UA |
|------|----|----|-----|
| Founded 2006 | ✓ | ✓ (2006 roku) | ✓ (2006 році) |
| Animation since 1991 | ✓ | ✓ (od 1991 roku) | ✓ (з 1991 року) |
| 1,000+ projects | ✓ (1,000+) | ✓ (ponad 1 000) | ✓ (понад 1 000) |
| 11 awards / 45 selections | ✓ | ✓ | ✓ |

Closing lines preserved:
- **EN:** Different worlds need different stories. We give them one language.
- **PL:** Różnorodne światy potrzebują różnorodnych historii. My nadajemy im jeden język.
- **UA:** Різноманітним світам потрібні різні історії. Ми даємо їм одну мову.

---

## Stats JSON keys

**Kept unused** — `about.stat1` through `about.stat4` remain in `en.json`, `pl.json`, and `ua.json` to preserve key parity across languages. No HTML references remain on the homepage.

---

## Bundle rebuild status

```
node www/js/rebuild-lang-bundle.js
→ bundle.js rebuilt (118 keys × 3 langs, 99 HTML refs OK)
```

No missing i18n keys reported by the rebuild script.

---

## Quality checklist

| Check | Result |
|-------|--------|
| 1. Homepage no longer displays separate stats block | ✓ Pass — no `.about-stats` in `index.html` |
| 2. Proof facts in About body (2006, 1991, 1,000+, 11, 45) | ✓ Pass — EN / PL / UA |
| 3. Hero headline unchanged | ✓ Pass — *Endless stories. Different worlds. One language.* |
| 4. EN hero subline unchanged | ✓ Pass — approved subline intact |
| 5. Nav unchanged | ✓ Pass — Original Worlds / Commercial Animation / About / Contact / Let's talk → |
| 6. PL/UA language switcher | ✓ Pass — bundle rebuilt; keys intact |
| 7. No missing i18n keys | ✓ Pass — rebuild validation OK |
| 8. No visible `[NEEDS CLIENT INPUT]` | ✓ Pass — none in `www/` HTML |
| 9. No CSS regression / empty spacing | ✓ Pass — `about-grid--single` prevents empty second-column gap on homepage |

**Unchanged (per scope):** EN hero, nav, doors, contact; subpage layouts; overall visual system.

---

## Layout notes

- **Homepage:** `.about-grid--single` collapses the former two-column About grid (copy + stats) to a single column so the removed stats column does not leave a visible empty gap on desktop.
- **Subpages:** `services.html` two-column `.about-grid` sections unchanged (still use default `1.2fr 0.8fr`).
- **Multiline body:** `.about-grid__body--multiline` uses `white-space: pre-line` so `\n\n` in JSON renders as paragraph breaks.

---

## Follow-up recommendations

1. **Optional cleanup:** Remove unused `about.stat1`–`about.stat4` keys and `.about-stats` CSS in a future pass if key parity is no longer required.
2. **Subpages:** PL/UA copy on `original.html` and `services.html` remains legacy vs EN brand language (out of scope for this task).
3. **Visual QA:** Quick browser check at desktop and mobile widths to confirm About paragraph rhythm reads well without the stat cards.
