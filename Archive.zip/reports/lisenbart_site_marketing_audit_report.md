# LISENBART.com — Site Report for Marketing Audit

**Date:** May 2026  
**Status:** Pre-launch / staging (static site, not yet fully wired for production)  
**Purpose of this document:** Feed to ChatGPT (or another LLM) for marketing, positioning, UX, SEO and conversion audit.

---

## 1. Executive summary

**LISENBART** is a B2B animation studio website positioned at the intersection of:

- **Original worlds** — films, children's IP, co-production / investment opportunities
- **Commercial animation** — brand films, explainers, motion design, mobile game cinematics

| Parameter | Value |
|---|---|
| Domain (planned) | lisenbart.com |
| Geography signal | Canada · Ukraine · Poland |
| Languages | English (default), Polish, Ukrainian |
| Primary tone | Author-driven studio craft + production speed; confident, not fluffy |
| Market intent (from project brief) | Poland + EU; agencies, game studios/publishers, brands |
| Stack | Static HTML / CSS / vanilla JS, JSON i18n |
| Deploy target (from brief) | Vercel |

---

## 2. Site architecture & user journeys

### Pages

| URL (planned) | File | Role |
|---|---|---|
| `/` | `index.html` | Home — hero showreel, two “doors”, clients marquee, about, contact |
| `/original.html` | `original.html` | Original Worlds — IP slate, investor/partner messaging, contact |
| `/services.html` | `services.html` | Commercial Animation — B2B services, cases, contact |
| (404) | `404.html` | Custom not found |

**Note:** Original project brief envisioned a single-page site + separate `/work` portfolio page. **Current build uses a 3-page + home “doors” model** instead of `/work`.

### Primary navigation (all pages)

- **Original Worlds** → `original.html`
- **Commercial Animation** → `services.html`
- **About** → `#about` (home only)
- **Contact** → `#contact` (per-page anchor)
- **CTA button:** “Let's talk →” → `#contact`
- **Language switcher:** EN / PL / UA (persisted in `localStorage`)

### Conversion paths

```
Home hero → Explore → Doors → Original OR Services → Contact
Home → Contact (direct)
Services → Original Worlds CTA (bottom, before contact)
Original → Commercial Animation CTA (in intro)
Any page → mailto:info@lisenbart.com
Any page → Social (Vimeo, LinkedIn, Facebook, YouTube)
```

---

## 3. Brand positioning (as expressed on site)

### Core narrative pillars

1. **“One language”** — movement, rhythm, image, character, visual craft unify original and commercial work
2. **Dual studio identity** — not “commercial-only vendor” nor “festival-only auteur”; both under one roof
3. **Credibility** — Since 2006, 1,000+ projects, 11 awards (Unnecessary Things), 45 festival selections, 300+ clients
4. **Speed + craft** — human creative direction; AI mentioned as production accelerator (services page)
5. **Original IP funnel** — projects tagged by readiness: Award-winning / In Development / Investment Ready

### Stated founder fact (canonical — do not alter in audit recommendations)

- Founded **2006** by **Dmytro Lisenbart**, active in animation since **1991**
- Short film **Unnecessary Things:** **11 international awards**, **45 festival selections**

---

## 4. Target audiences (implicit from copy)

| Segment | Where addressed | What they’re offered |
|---|---|---|
| **Advertising agencies & brands** | `services.html` — Brands & Agencies | Campaign animation, explainers, pitch/social assets |
| **Game studios & publishers** | `services.html` — Games section | Cinematics, trailers, cutscenes, marketing packs |
| **Investors / broadcasters / licensors** | `original.html` intro | Co-finance or full finance original IP |
| **Co-production partners** | Original project cards | Slate of 6 projects with status badges |
| **General B2B leads** | All contact forms | Email + message, 24h response promise |

---

## 5. Full copy inventory (English — source language)

### 5.1 Global meta

- **Title:** LISENBART — Original Worlds & Commercial Animation
- **Meta description:** Animation studio creating original animated worlds and shaping commercial animation for brands, agencies, game studios and publishers — through one language of movement, rhythm and visual craft.

### 5.2 Home (`index.html`)

**Hero**

- Label: Animation Studio
- H1: Endless stories. Different worlds. One language.
- Stats line: Since 2006 / 1,000+ Projects delivered / 11 International awards / 300+ Clients
- Location: Canada · Ukraine · Poland

**Door cards**

- Original Worlds: Animated films, children's stories and original IP developed inside LISENBART.
- Commercial Animation: Brand films, explainers, motion design and mobile game cinematics shaped through movement, rhythm and visual craft.

**About**

- Headline: We shape worlds through movement, rhythm and visual craft.
- Body:

> LISENBART works across original films, animated IP and commercial production. Some stories begin inside the studio. Others come from a brand, an agency or a game world that needs to move, speak and be remembered.
>
> What connects them is not format. It is language — movement, rhythm, image, character and visual craft.
>
> Founded in 2006 by animation director and producer Dmytro Lisenbart, whose work in animation began in 1991, the studio has delivered 1,000+ commercial animation projects. Its short film Unnecessary Things received 11 international awards across 45 festival selections.
>
> Different worlds need different stories. We give them one language.

**Contact (home)**

- Headline: Let's give your world a language.
- Subline: Tell us what you want to create. We respond within 24 hours.
- Form fields: **Email + Message only** (minimal)

### 5.3 Original Worlds (`original.html`)

- **Page title:** Original Worlds — LISENBART
- **Meta:** Animated films, children's stories and original IP developed inside LISENBART.
- **H1:** Where our own stories become animated worlds.
- **Subline:** Films, children's stories and original IP created inside LISENBART — shaped by the same language of movement, rhythm and visual craft.

**Intro (investor-facing)**

> Original projects are where LISENBART builds its own characters, worlds and voice — from festival-recognised short films to children's IPs in active development. Each project has a defined format, a clear visual identity and potential to grow across formats and markets. We are open to investors, broadcasters, licensing partners and development funds — whether you are looking to co-finance or fully finance a project.

**Proof line:** The same craft — in an original film and in a commercial project.

**Cross-sell CTA:** Curious about our commercial work? Explore Commercial Animation →

**Project slate (6 cards)**

| Project | Status (EN) | One-line pitch |
|---|---|---|
| Unnecessary Things | Award-winning animated short | 11 awards, 45 festivals — director identity piece |
| SmartBabies | In Development | Educational brand for toddlers/preschool, YouTube/Shorts/licensing |
| BibiBoo | Investment Ready | Preschool characters, songs, digital-first |
| Pershosvit | In Development | Ukrainian-rooted children's learning universe, multi-format |
| The Last Cossack | Investment Ready | Ukrainian folklore fantasy, franchise potential |
| Boy from City B. / Tears of God | Investment Ready | Author-driven, festival-oriented intimate story |

**PL localization note:** Last Cossack title in Polish = **Ostatni Bohater** (EN/UA keep “The Last Cossack”).

**Contact (original-specific)**

- Headline: Let's build one of these worlds together.
- Subline: Tell us which project you want to discuss. We respond within 24 hours.

### 5.4 Commercial Animation (`services.html`)

- **Meta:** Commercial animation for brands, agencies, game studios and publishers — brand films, explainer videos, motion design and game cinematics.
- **H1:** Animation for Brands, Agencies, Game Studios and Publishers
- **Subline:** Brand films, explainer videos, motion design and game cinematics — crafted with the rhythm, precision and visual language of an author-driven studio.

**Sections**

- When an idea needs to come alive (intro)
- Studio craft. Production speed. (AI-assisted production messaging)
- For Brands & Agencies + tag list
- For Game Studios & Publishers + tag list
- Selected Commercial Work (2 generic case cards — placeholders)
- **Cross-sell CTA (bottom, before contact):** Curious about the studio behind the work? Explore Original Worlds →

**Contact (services-specific)**

- Headline: Let's help your idea come alive.
- Subline: Leave your email — we respond within 24 hours.

**Service tags (EN)**

- Brands: Brand Films · Explainer Videos · Motion Design · Social Animation · Pitch Videos · Live Action + Animation · 2D Animation · 3D Animation
- Games: Mobile Game Cinematics · Game Trailers · In-Game Cutscenes · Character Animation · Marketing Packs · UI/UX Animation · 2D Animation · 3D Animation

**Approach body (AI mention)**

> Most studios make you choose between quality and speed. We don't. Creative decisions stay with people — direction, rhythm, performance and final visual taste. AI lets us explore more, iterate faster and compress production cycles without losing quality. The result: studio-level craft delivered in timelines that simply weren't possible before.

---

## 6. Internationalization (i18n)

- **122 translation keys × 3 languages** (validated by `node js/rebuild-lang-bundle.js`)
- Runtime: `fetch('lang/{en|pl|ua}.json')` + fallback `lang/bundle.js`
- Browser language detection on first visit; user choice saved in `localStorage`
- **Investment Ready** kept in English even in PL/UA status labels (intentional product term)

**Audit question for GPT:** Is PL/UA copy equally strong for EU/Polish/Ukrainian markets, or does EN lead and translations lag in tone/SEO keywords?

---

## 7. Visual & UX system (summary)

| Element | Detail |
|---|---|
| **Palette** | Dark bg `#0e0d0c`, accent orange `#ff4d00`, light contact band `#f5f4f0` |
| **Font** | Inter (Google Fonts) |
| **Hero** | Full-width Vimeo embed (muted autoplay loop), volume control |
| **Motion** | Scroll reveal animations; clients marquee (3 rows); custom cursor (desktop) |
| **Status badges** | Blue = In Development · Gold = Award-winning · Green = Investment Ready |
| **Responsive** | Mobile nav, stacked grids, hero stats auto-scale to one line |

---

## 8. Trust & social proof — what exists vs. missing

### Present

- Vimeo showreel on homepage (video ID 849899875)
- Stats bar (2006, 1000+, 11 awards, 300+ clients)
- Unnecessary Things awards copy
- Client marquee section (“Trusted by”)
- Named clients in JSON: **Playtika**, **SuperPlay** (+ generic “Client logo” placeholders)
- Social links: Vimeo, LinkedIn, Facebook, YouTube
- Email: info@lisenbart.com

### Missing / placeholder

- **No real client logos** in marquee (8× repeated placeholder per row × 3 rows)
- **No project cover images** — all cards say “Visual coming soon” / “Project visual”
- **No door card visuals** on homepage
- **Commercial case studies** are category-level, not named client work (except implied game studio work)
- **No testimonials, press quotes, or festival laurels graphics**
- **No team page / director bio page** (founder mentioned only in about paragraph)
- **No favicon or OG image** configured
- **No `/work` portfolio page** from original brief

---

## 9. SEO & discoverability

### Implemented

- `robots.txt` — allow all, sitemap URL
- `sitemap.xml` — home, original, services (404 excluded)
- Per-page `<title>` and meta description (static + i18n dynamic update via JS)
- Basic Open Graph tags on main pages (`og:title`, `og:description`, `og:site_name`, `og:type`)
- Twitter card: summary
- Semantic headings (H1 per page)
- `theme-color`, `color-scheme: dark`

### Not implemented / gaps

- **No `og:image`**
- **No favicon / apple-touch-icon**
- **No hreflang** tags for EN/PL/UA
- **No structured data** (Organization, VideoObject, CreativeWork)
- **No analytics** (GA4, Plausible, etc.)
- **No canonical URLs**
- Meta descriptions may differ between static HTML fallback and JSON (JS overwrites on load)
- Single-page JS i18n may be **weaker for crawlers** that don’t execute JS (content falls back to EN in HTML)

---

## 10. Lead capture & forms

| Page | Fields | Backend |
|---|---|---|
| Home | Email, Message | **Mock only** — shows success, no send |
| Original | Email, Message | **Mock only** |
| Services | Email, Message | **Mock only** |

**Prepared for Formspree:** hidden `_subject`, `_replyto`, `page_url`, honeypot `_gotcha`, source tag (`home` / `original` / `services`).

**Not in live forms (but exist in JSON):** Name, Company, “What do you need?” dropdown with options (co-production, brand, game, explainer, motion, other) — **defined in i18n but not rendered in HTML**.

**Audit questions:**

- Is email-only too minimal for B2B agency leads?
- Should “What do you need?” return to qualify leads?
- Is “24 hours” response SLA backed operationally?

---

## 11. Technical stack

- Static HTML / CSS / vanilla JS
- No framework, no build step for site (only `node js/rebuild-lang-bundle.js` for i18n validation)
- Deploy target (from brief): **Vercel**
- Local preview: `cd www && python3 -m http.server 8080`
- Single CSS file ~1,700 lines (responsive merged)
- JS modules: `main.js` (forms, hero video fit, hero stats scale, cursor, reveal), `lang.js` (i18n), `clients-marquee.js` (injected marquee on index + services)

---

## 12. Content / messaging tensions (useful for audit)

1. **Hero message vs. services headline** — Home says poetic “Endless stories…”; Services says literal B2B “Animation for Brands, Agencies…”
2. **AI mention** — Only on services (`approachBody`); absent from home/about — could help or hurt depending on audience
3. **Investment Ready in English** on PL/UA site — deliberate jargon or localization gap?
4. **Original vs. commercial balance** — Home gives equal “doors”; services page is deeper for commercial buyers; original page now explicitly targets investors
5. **Case studies** — Commercial work section doesn’t show Playtika/SuperPlay visually despite client marquee
6. **Brief vs. build** — Docs still describe `/work`, `#services` on homepage, fuller contact form

---

## 13. Pre-launch checklist (blocking items)

- [ ] Wire Formspree (or other) in `js/main.js`
- [ ] Add favicon + OG image (`assets/brand/`)
- [ ] Replace all media placeholders with real assets
- [ ] Add real client SVG logos to marquee
- [ ] Decide on hreflang / SEO strategy for 3 languages
- [ ] Add analytics
- [ ] Test contact flow end-to-end
- [ ] Cache-bust CSS after deploy if needed

---

## 14. Suggested prompts for ChatGPT marketing audit

Copy-paste one or more:

**Positioning**

> Audit LISENBART.com positioning for EU B2B animation buyers (agencies, game publishers, investors). Is the “one language of movement” narrative differentiated or generic? Compare Original Worlds vs Commercial Animation split.

**Conversion**

> Review conversion paths and CTAs. Where do we lose agency vs. investor vs. game studio leads? Should forms collect more fields?

**SEO**

> Keyword gap analysis for EN/PL/UA given current copy. Recommend title/meta improvements and whether hreflang + static language URLs are needed.

**Trust**

> Given missing portfolio visuals and placeholder clients, what minimum social proof is needed before launch?

**Polish market**

> Is PL copy market-ready for Polish agencies and producers? Flag awkward calques and suggest local B2B phrasing.

**Investor page**

> Evaluate original.html introBody for co-production/investment outreach. What’s missing for broadcasters and funds?

---

## 15. Key files reference

```
www/index.html          — Home
www/original.html       — Original Worlds
www/services.html       — Commercial Animation
www/404.html            — Not found
www/lang/en.json        — EN source copy
www/lang/pl.json        — Polish
www/lang/ua.json        — Ukrainian
www/css/style.css       — All styles
www/js/main.js          — Forms, hero, UX
www/js/lang.js          — i18n runtime
www/robots.txt
www/sitemap.xml
docs/lisenbart_website_brief.md — Original strategy brief (partially superseded)
reports/                        — Copy change logs and audits
```

---

**End of report.**

Paste this document into ChatGPT and ask for a structured audit: positioning score, conversion recommendations, SEO keyword map, competitive angles, and pre-launch priority list.
