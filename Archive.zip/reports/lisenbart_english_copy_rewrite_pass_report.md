# LISENBART — English Copy Rewrite Pass Report

**Date:** 2026-05-28  
**Scope:** English copy rewrite per audit and copy deck. No visual redesign. Two-pillar IA preserved.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/en.json` | Full English copy deck (source of truth) |
| `www/lang/pl.json` | Nav, placeholders, form, 404, meta/page titles, new keys (structure parity) |
| `www/lang/ua.json` | Same minimal sync as PL |
| `www/lang/bundle.js` | Rebuilt from JSON |
| `www/js/lang.js` | `data-i18n-placeholder` support for textarea |
| `www/js/main.js` | Form success/error fallbacks aligned with new copy |
| `www/index.html` | Hero, doors, about, clients, nav fallbacks, meta, form placeholder |
| `www/original.html` | Nav, intro, project cards, media placeholders, form placeholder |
| `www/services.html` | Nav, intro/blocks/cases, media placeholders, document title, form placeholder |
| `www/404.html` | Nav, headline/body/CTA structure |
| `www/css/style.css` | `.page-error__headline` for 404 layout |

---

## English copy changed (high level)

### Home (`index.html` + `en.json`)
- **Hero:** “Original content. Client work. One animation studio.” + updated subline (craft bridge to client work).
- **Doors:** Pillar 1 “Original Content”; Pillar 2 “Client Work” (not “Animation on Demand” on the door).
- **About:** New headline, body, core line (“Award-winning craft, applied to real production.”).
- **Contact:** Unchanged structure; success/error messages updated in JSON.

### Original (`original.html`)
- Intro: “Animated worlds we build ourselves.” + proof line linking craft to client animation.
- Project descriptions shortened (web-friendly).
- Contact block unchanged in intent; copy from deck applied in JSON.

### Client Work (`services.html`)
- **Nav / document title:** “Client Work”.
- **Page H1:** “Animation on Demand” (unchanged).
- Intro, brands/games blocks, approach, cases, contact per deck.
- Case section label: “Selected Client Work”.

### 404
- “This frame is missing.” + body + “Back to home →”.

### Meta
- Home: `LISENBART — Original Content & Client Animation`
- Original: `Original Content — LISENBART`
- Services tab title: `Client Work — LISENBART` (H1 remains Animation on Demand)

### Form
- Placeholder via `contact.messagePlaceholder`.
- Success/error messages per deck.

---

## Navigation labels changed

| Location | Before | After |
|----------|--------|-------|
| Primary nav (all pages) | Original / Services | **Original Content** / **Client Work** |
| Mobile nav | Same | Same |
| CTA | Let's talk → | Unchanged |

URLs unchanged: `original.html`, `services.html`.

---

## Placeholder cleanup

| Area | Before | After |
|------|--------|-------|
| Door media | `[NEEDS CLIENT INPUT]…` | “Visual coming soon” (`aria-hidden` on index) |
| Client logos | NEEDS CLIENT INPUT | Playtika / SuperPlay / Client logo |
| Original project media | Hardcoded NEEDS | `original.mediaPlaceholder` → “Project visual” |
| Services case media | Hardcoded NEEDS | `services.caseMediaPlaceholder` → “Project visual” |

**Public site (`www/`):** zero `[NEEDS CLIENT INPUT]` strings remaining.

---

## Remaining risks

1. **PL/UA body copy** — Not fully rewritten; only structural/nav/placeholder/404/form sync. Long PL/UA project paragraphs may still read heavier than English until a dedicated translation pass.
2. **Placeholder media** — Text placeholders remain until real stills/logos/video are supplied; `aria-hidden` hides door media labels from assistive tech (intentional until assets exist).
3. **Boy from City B.** — Public copy notes logline/audience/format TBC before launch (per canon).
4. **Form backend** — Copy assumes 24h response; delivery depends on live form endpoint (unchanged in this pass).
5. **Client logo row** — Playtika/SuperPlay shown as text placeholders until SVG assets are added.

---

## PL/UA sync issues

- **Key parity:** EN / PL / UA — 0 missing / 0 extra keys (verified).
- **Nav:** PL “Treści autorskie” / “Praca dla klientów”; UA “Власний контент” / “Клієнтська робота”.
- **Services `pageTitle`:** Localized to match “Client Work” tab title; H1 still “Animation on Demand” / localized equivalent on page.
- **Project descriptions:** PL/UA still use longer legacy text in JSON; English is authoritative.

---

## Final checklist

| Check | Status |
|-------|--------|
| Top nav: Original Content / Client Work / About / Contact / Let's talk → | ✅ |
| Home two pillars: Original Content + Client Work | ✅ |
| `services.html` H1: Animation on Demand | ✅ |
| `original.html` H1: Original Content | ✅ |
| No visible `[NEEDS CLIENT INPUT]` in `www/` | ✅ |
| No old three-pillar nav (Film/Games/IP) | ✅ |
| EN/PL/UA i18n key parity | ✅ |
| Internal links (`original.html`, `services.html`, `#about`, `#contact`) | ✅ |
| No invented clients, awards, prices, or claims | ✅ |
| Banned/marketing fluff scan in live `www/` copy | ✅ (none found) |
| Canon: 2006, since 1991, 1,000+, 11 awards / 45 selections, Playtika/SuperPlay, Canada · Ukraine · Poland, 24h, human + AI | ✅ |

---

## How to verify locally

1. Open `www/index.html` in a browser (or local server).
2. Confirm nav labels and hero/doors/about copy in English.
3. Switch PL/UA — nav and placeholders should not break.
4. Visit `original.html`, `services.html`, and a non-existent path for 404.
5. Submit contact form (if endpoint configured) and check success/error strings.

Rebuild bundle after any JSON edit:

```bash
node www/js/rebuild-lang-bundle.js
```
