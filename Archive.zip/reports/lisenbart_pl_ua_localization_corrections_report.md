# LISENBART PL/UA Localization Corrections Report

**Date:** 2026-05-28  
**Scope:** Targeted owner corrections for homepage PL/UA copy. English unchanged.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/pl.json` | Hero headline, Original Worlds door description, contact headline |
| `www/lang/ua.json` | Hero headline, Original Worlds door description, contact headline |
| `www/lang/bundle.js` | Rebuilt |

**Not changed:** `www/lang/en.json`, HTML, CSS, subpage-specific PL/UA strings.

---

## Ukrainian corrections applied

| Key | Before | After |
|-----|--------|-------|
| `hero.headline` | Безкінечні історії. Різні світи. Одна мова. | **Нескінченні історії. Різноманітні світи. Одна мова.** |
| `doors.original.desc` | …та власні IP, що розробляються всередині LISENBART. | **Анімаційні фільми, дитячі історії та власні IP.** |
| `contact.headline` | Даймо вашому світу мову. | **Нехай ваш світ заговорить!** |

---

## Polish corrections applied

| Key | Before | After |
|-----|--------|-------|
| `hero.headline` | Nieskończone historie. Różne światy. Jeden język. | **Niekończące się historie. Różnorodne światy. Jeden język.** |
| `doors.original.desc` | …i autorskie IP rozwijane wewnątrz LISENBART. | **Filmy animowane, historie dla dzieci i autorskie IP.** |
| `contact.headline` | Nadajmy Twojemu światu język. | **Niech Twój świat przemówi!** |

---

## Bundle rebuild status

```bash
node www/js/rebuild-lang-bundle.js
```

**Result:** Success — key parity and HTML i18n refs validated.

---

## Quality checklist

| # | Check | Result |
|---|-------|--------|
| 1 | UA hero: Нескінченні історії. Різноманітні світи. Одна мова. | ✅ |
| 2 | PL hero: Niekończące się historie. Różnorodne światy. Jeden język. | ✅ |
| 3 | UA door: Анімаційні фільми, дитячі історії та власні IP. | ✅ |
| 4 | PL door: Filmy animowane, historie dla dzieci i autorskie IP. | ✅ |
| 5 | UA contact: Нехай ваш світ заговорить! | ✅ |
| 6 | PL contact: Niech Twój świat przemówi! | ✅ |
| 7 | English unchanged | ✅ |
| 8 | No missing i18n keys | ✅ |
| 9 | Language switcher works (bundle valid) | ✅ |
| 10 | Bundle rebuilt | ✅ |

---

## Notes

- Corrections apply to homepage keys used on `index.html` (`hero.*`, `doors.original.desc`, `contact.headline`). Shared nav/form keys unchanged in this pass.
- `original.subline` on `original.html` may still carry longer legacy PL/UA text until a subpage localization pass.
