# LISENBART English Copy Audit — Current State

## 1. Executive Summary

The current English copy is structurally strong after the 2-pillar refactor and clearly reflects the intended model: `Original Content` + `Animation on Demand`. Core brand facts are consistent with canon (2006, since 1991, 1,000+ projects, 11 awards / 45 selections, Playtika + SuperPlay, Canada · Ukraine · Poland, 24-hour response).

What is working:
- Strategic logic is present across Home, Original, and Services.
- The voice is generally studio-level (not generic-agency fluff).
- Mobile game cinematics are correctly integrated into client work.
- Contact language is practical and commercially usable.

Main gaps:
- Top-level nav labels (`Original`, `Services`) are too generic vs page-level specificity.
- Copy density is uneven: long IP descriptions vs short service/case blocks.
- Some phrasing is strong but slightly abstract/cinematic where B2B clarity should lead.
- Visible `[NEEDS CLIENT INPUT]` placeholder copy reduces perceived readiness.
- A few wording mismatches create micro-friction (`authorial craft`, `stories built as worlds`, “and game studios” vs “mobile game studios”).

Overall: not yet “final sales copy,” but a solid base ready for a focused rewrite pass.

## 2. Current Copy Inventory

### Navigation labels
- Primary: `Original`, `Services`
- Secondary: `About`, `Contact`
- CTA: `Let's talk →`
- Mobile close: `Close`

### Home (`index.html`)
- Hero label: `Animation Studio`
- Hero headline: `Original content. Animation on demand. One studio.`
- Hero subline: `LISENBART creates award-winning animated films and original IP, while producing high-quality animation for brands, agencies and mobile game studios.`
- Doors:
  - `Original Content` / `Explore original work →`
  - `Animation on Demand` / `Start a project →`
- Clients: `Trusted by` (+ placeholder logo labels)
- About:
  - Headline: `A studio where original films and client animation strengthen each other.`
  - Body includes all key proof points and studio logic
  - Core line: `Original work proves our craft. Client work brings that craft to brands, agencies and games.`
- Contact:
  - Headline: `Tell us what you need to animate.`
  - Subline: `Send us a short brief. We respond within 24 hours.`
  - CTA button: `Send →`

### Original Content (`original.html`)
- Hero headline: `Original Content`
- Subline: `Animated films, children's content and original IP developed in-house by LISENBART.`
- Intro headline: `Stories built as worlds.`
- Proof line connects original craft to client value
- Project cards:
  - Unnecessary Things
  - SmartBabies
  - BibiBoo
  - Pershosvit
  - The Last Cossack
  - Boy from City B. / Tears of God
- Contact variant:
  - `Interested in original content, co-production or licensing?`

### Services (`services.html`)
- Hero headline: `Animation on Demand`
- Subline explicitly includes brand/commercial + mobile game cinematics
- Sections:
  - `Award-winning craft, applied to client work.`
  - `For Brands & Agencies`
  - `For Mobile Game Studios`
  - `Human direction. AI speed.`
  - `Client examples`
- Cases:
  - `Playtika / SuperPlay`
  - `Commercial Animation`
- Contact variant:
  - `Ready to start a client animation project?`

### 404 (`404.html`)
- `Page not found — LISENBART`
- `This page doesn't exist.`
- `Back to home`

### Meta copy
- Home title/description align with 2-pillar strategy.
- Original/Services have page-specific title + description through i18n keys.

### Contact form system copy
- Field labels: Name, Company, Email, What do you need?, Message
- Need options: Brand animation, Mobile game cinematics, Explainer video, Motion design, Other
- Feedback:
  - Success: `Thank you — we'll get back to you within 24 hours.`
  - Error: `Something went wrong. Please email info@lisenbart.com directly.`
  - JS fallback strings exist: `Thank you.` / `Error.`

### Footer copy
- `© 2026 LISENBART`
- Location: `Canada · Ukraine · Poland`

### Visible placeholder copy
- Door media, client logos, project visuals, and service case visuals still display `[NEEDS CLIENT INPUT]`.

## 3. Navigation Clarity Audit

| Current label | What it communicates | Potential confusion | Better alternatives |
|---|---|---|---|
| `Original` | A “creative/original” area | Could mean “about us”, “unique style”, not clearly content/IP | `Original Content`, `Studio Originals`, `Original Work` |
| `Services` | General service offering | Too broad/agency-generic; weak differentiation from any studio | `Animation on Demand`, `Client Work`, `Commercial Animation` |
| `Original Content` (page headline/door) | Studio-owned films/IP | Clear and strategic | Keep |
| `Animation on Demand` (page headline/door) | Client production pillar | Strategic and differentiated, but not universal for all B2B visitors | Keep for headline; consider simpler nav variant |
| `Client examples` | Proof of commercial work | Slightly neutral; not conversion-forward | `Selected Client Work`, `Client Cases` |
| `Commercial Animation` (case title) | Service category | Clear but broad | Keep as category language |

Assessment:
- Navigation is functional but not maximally clear for first-time B2B scanning.
- Current split (`Original` + `Services`) is short but loses strategic precision.

## 4. Tone of Voice Audit

### Strengths
- Professional and direct in most core sections.
- Confident without hype-heavy vocabulary.
- Human-led + AI-accelerated positioning is clear and responsibly framed.
- Not written as a personal portfolio voice; mostly studio “we”.

### Inconsistencies / weak spots
- **Too abstract/cinematic in places:** `Stories built as worlds.` and some long IP passages can feel festival-pitch heavy for commercial visitors.
- **Uneven density:** Services copy is concise; original project copy is very long and detail-heavy.
- **Minor diction mismatch:** `authorial craft` reads more film-critic than buyer-facing.
- **Mixed audience tone:** Original page leans partner/development language; services page is buyer language (good individually, but bridge language can be tighter).
- **AI message consistency:** Excellent in services/about, but less visibly repeated in key CTA/proof moments.

Verdict: voice is mostly aligned, but needs one editorial pass for tighter B2B clarity and rhythm consistency.

## 5. Strategic Clarity Audit

### What works
- 2-pillar architecture is explicit on Home and reinforced on both pillar pages.
- “Original proves craft / client work applies craft” logic appears in About + Original + Services.
- Mobile game cinematics are clearly nested under client work (correct).

### Remaining ambiguity
- Top nav labels do not fully carry the 2-pillar strategy by themselves.
- Some readers may parse “Original” as “brand philosophy” instead of owned content slate.
- The strongest business bridge (awards -> commercial trust/value) exists but is not always foregrounded in service proof copy.

Conclusion: strategic framework is present and mostly clear, but naming + proof hierarchy can be sharpened.

## 6. Sales Strength Audit

### Original Content as commercial trust signal
- Good: Unnecessary Things award proof is explicit.
- Needs stronger “why this matters for clients” repetition near key conversion points.

### Animation on Demand as sellable offer
- Good: clear audience split, service tags, production discipline framing.
- Good: Playtika/SuperPlay proof is used correctly.
- Weak: case section is concise but still generic due placeholder visuals + short specificity.

### Conversion language
- Contact CTAs are practical and low-friction.
- Core promise is clear, but value differentiation could be more explicit in hero and service intro (e.g., faster iteration + quality retention + campaign readiness).

Sales verdict: strong strategic skeleton, medium commercial persuasion in current wording.

## 7. Page-by-Page Audit

### Home
- **Current headline:** `Original content. Animation on demand. One studio.`
- **Current subline:** LISENBART creates award-winning films/IP and client animation.
- **Key sections:** Hero, 2 doors, Clients, About, Contact.
- **What works:**
  - Clear dual model.
  - Strong strategic sentence-level clarity.
  - About section contains full proof stack.
- **What is weak:**
  - Nav labels less explicit than the hero.
  - Placeholder blocks reduce trust/readiness.
  - About paragraph is information-dense; may be long for skim behavior.
- **Recommended rewrite direction:**
  - Keep structure, tighten sentence rhythm, and elevate buyer outcome language earlier.

### Original Content
- **Current headline:** `Original Content`
- **Current subline:** in-house films, children’s content, IP.
- **Key sections:** Intro + proof line + 6 project cards + contact.
- **What works:**
  - Full slate is visible.
  - Partnership/co-production intent is clear.
  - Strong creative authority.
- **What is weak:**
  - Descriptions are too long for web scanning.
  - Tone drifts toward development deck language.
  - Not all projects connect equally to commercial trust value.
- **Recommended rewrite direction:**
  - Keep all projects; compress each card to sharper web-length hooks + one business-relevant proof angle.

### Animation on Demand / Services
- **Current headline:** `Animation on Demand`
- **Current subline:** full offer incl. mobile game cinematics.
- **Key sections:** Intro, Brands/Agencies block, Mobile Game block, AI approach, cases, contact.
- **What works:**
  - Audience segmentation is clear.
  - Terminology is generally strong and relevant.
  - Human-direction/AI-speed message is on-strategy.
- **What is weak:**
  - “Client examples” currently lightweight and partially generic.
  - Some phrases are descriptive rather than persuasive.
  - Could better emphasize production outcomes (delivery confidence, campaign readiness, iteration speed).
- **Recommended rewrite direction:**
  - Preserve structure; strengthen benefits and specificity per audience block and case.

### 404
- **Current headline:** `404`
- **Current subline:** `This page doesn't exist.`
- **What works:** clear, minimal, functional.
- **What is weak:** no recovery copy beyond back-home link.
- **Recommended rewrite direction:** optional micro-polish only (low priority).

### Legacy / Redirect Pages
- `film.html`, `games.html`, `ip.html` do not exist anymore (removed).
- Audit note: no legacy copy currently exposed to users in these files.

## 8. Naming System Review

### Original-side naming

| Option | Clarity | B2B credibility | Emotional quality | Fit with LISENBART | Confusion risk |
|---|---:|---:|---:|---:|---:|
| `Original` | 2/5 | 3/5 | 3/5 | 3/5 | High |
| `Original Content` | 5/5 | 5/5 | 3/5 | 5/5 | Low |
| `Original Work` | 4/5 | 4/5 | 3/5 | 4/5 | Low-Med |
| `Studio Originals` | 4/5 | 4/5 | 4/5 | 5/5 | Low |
| `In-House Projects` | 4/5 | 4/5 | 2/5 | 3/5 | Med |

### Client-side naming

| Option | Clarity | B2B credibility | Emotional quality | Fit with LISENBART | Confusion risk |
|---|---:|---:|---:|---:|---:|
| `Services` | 3/5 | 3/5 | 2/5 | 3/5 | Med |
| `Client Work` | 5/5 | 5/5 | 3/5 | 5/5 | Low |
| `Animation on Demand` | 4/5 | 5/5 | 4/5 | 5/5 | Low-Med |
| `Commercial Animation` | 5/5 | 5/5 | 3/5 | 5/5 | Low |
| `Work for Clients` | 5/5 | 4/5 | 2/5 | 4/5 | Low |

### Recommended navigation labels

Best-practice pair for max clarity + strategy:
- `Original Content`
- `Client Work`

Alternative (more distinctive but slightly less instant clarity):
- `Original Content`
- `Animation on Demand`

### Recommended page headlines

Keep:
- `Original Content`
- `Animation on Demand`

Reason: strong strategic framing and differentiation. For top nav, shorter clarity-led labels are better.

## 9. Copy Issues by Priority

### P0 — Must Fix
- Top nav labels are too generic (`Original`, `Services`) relative to strategic model and first-scan comprehension.
- Visible `[NEEDS CLIENT INPUT]` placeholders on public-facing sections reduce credibility.
- Services proof section is under-specific for sales conversion (especially with placeholder visuals).

### P1 — Should Fix
- Original project descriptions are too long for web scanning; reduce and sharpen.
- Bridge message (awards/original craft -> client value) should appear more prominently in commercial sections.
- Replace a few high-register expressions (`authorial craft`, etc.) with clearer B2B phrasing.
- Normalize wording around “mobile game studios” consistently where relevant.

### P2 — Polish Later
- 404 microcopy enhancement.
- Fine-tune CTA hierarchy and repeated phrasing to avoid semantic fatigue.
- Add more concise section-level conversion hooks.

## 10. Recommended Rewrite Direction

Target sound:
- A professional animation studio voice: precise, human, commercially literate, visually sophisticated.
- Cinematic credibility with production discipline.
- Confident, not inflated.

Main current copy problem:
- Naming + proof hierarchy is slightly weaker than the strategic architecture itself.

Rewrite order:
1. Navigation labels (clarity first).
2. Services page (sales-strength and specificity).
3. Home bridge messaging and scanability.
4. Original page compression and buyer-relevant framing.
5. Minor polish (404, repeated phrasing).

Keep or replace `Animation on Demand`?
- **Keep as page headline** (strong strategic phrase).
- For nav, prefer clearer B2B pairing:
  - `Original Content` + `Client Work` (recommended)
  - or keep `Animation on Demand` in nav if brand wants distinctiveness over instant clarity.

## 11. Files Reviewed

- `www/lang/en.json`
- `www/index.html`
- `www/original.html`
- `www/services.html`
- `www/404.html`
- `www/js/main.js` (for form feedback copy behavior)
- Legacy existence check:
  - `www/film.html` (not present)
  - `www/games.html` (not present)
  - `www/ip.html` (not present)
