# LISENBART Index PL/UA Localization Report

**Date:** 2026-05-28  
**Scope:** Polish and Ukrainian localization for homepage copy and shared nav/form keys. English unchanged.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/pl.json` | Homepage + shared keys localized per approved PL strings |
| `www/lang/ua.json` | Homepage + shared keys localized per approved UA strings |
| `www/lang/bundle.js` | Rebuilt |

**Not changed:** `www/lang/en.json`, HTML files, CSS, `original.*` / `services.*` page-specific PL/UA copy (legacy strings remain on subpages until dedicated pass).

---

## PL localization summary

Updated keys:

- `meta.title`, `meta.description`
- `nav.original`, `nav.services` (Autorskie światy / Animacja komercyjna)
- `hero.*` (headline, subline, studio, scroll)
- `doors.original.*`, `doors.services.*`
- `clients.*` (unchanged labels; logo3 already correct)
- `about.*` (headline, body, stat labels)
- `contact.headline`, `contact.subline`, form fields, placeholders, success/error, `needOptions.*`

**Hero headline:** Nieskończone historie. Różne światy. Jeden język.

**Contact headline:** Nadajmy Twojemu światu język.

**Nav:** Autorskie światy / Animacja komercyjna / O nas / Kontakt / Porozmawiajmy →

---

## UA localization summary

Updated keys: same structure as PL.

- `meta.title`, `meta.description`
- `nav.*` (Авторські світи / Комерційна анімація / Поговорімо →)
- `hero.*` (Студія анімації, ↓ Дослідити)
- `doors.*`
- `about.*`
- `contact.*` (shared form + home headline/subline)

**Hero headline:** Безкінечні історії. Різні світи. Одна мова.

**Contact headline:** Даймо вашому світу мову.

**Nav:** Авторські світи / Комерційна анімація / Про нас / Контакт / Поговорімо →

---

## Keys added or renamed

**None.** All updates were value changes on existing keys. Key parity: 118 keys × 3 languages.

---

## Bundle rebuild status

```bash
node www/js/rebuild-lang-bundle.js
```

**Result:** Success — `118 keys × 3 langs, 107 HTML refs OK`

---

## Quality checklist

| # | Check | Result |
|---|-------|--------|
| 1 | English unchanged | ✅ |
| 2 | PL sounds natural (brand language, not literal EN) | ✅ |
| 3 | UA sounds natural | ✅ |
| 4 | PL/UA preserve: stories / worlds / one language / movement, rhythm, craft | ✅ |
| 5 | PL nav correct | ✅ |
| 6 | UA nav correct | ✅ |
| 7 | Co-production / Original IP first in dropdown (PL/UA) | ✅ |
| 8 | EN/PL/UA key parity | ✅ |
| 9 | No missing i18n keys | ✅ |
| 10 | Language switcher functional (bundle valid) | ✅ |
| 11 | No CSS changes | ✅ |
| 12 | No [NEEDS CLIENT INPUT] | ✅ |
| 13 | No old nav labels on index when PL/UA selected | ✅ |
| 14 | Bundle rebuilt | ✅ |

---

## Remaining localization risks

1. **Subpages (original.html, services.html)** — PL/UA still use older copy for page heroes, intros, project cards, and page-specific contact headlines (`contact.original.*`, `contact.services.*`). Nav and form will switch correctly; body copy on subpages will feel mixed until a follow-up pass.

2. **Meta on subpages** — `original.pageTitle`, `services.pageTitle` and descriptions in PL/UA still reference old naming (e.g. “Treści autorskie”, “Praca dla klientów”). Home `meta.*` is updated; subpage titles when switching language on those pages may lag.

3. **About body as single paragraph** — Multi-paragraph PL/UA about text is stored as one string (matches EN HTML structure). Optional future: split into multiple `<p>` elements per language.

4. **PL/UA meta descriptions** — Aligned with brand formula; not separately client-approved beyond the localization brief (derived from EN meta intent).

5. **Social link labels** — Vimeo/LinkedIn/etc. remain brand names in all languages (no JSON keys; hardcoded in HTML — correct).

---

## Verify locally

1. Open `index.html` via local server.
2. Switch to PL — confirm hero, doors, about, contact, form dropdown.
3. Switch to UA — same sections.
4. Switch back to EN — confirm approved English unchanged.
