# LISENBART — Original Worlds Copy Corrections Report

**Date:** 2026-05-28  
**Scope:** Targeted EN / UA / PL copy corrections for `original.html` only.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/en.json` | Intro headline shortened |
| `www/lang/pl.json` | Intro headline, contact, page labels, projects label, Boy from City B. cleanup |
| `www/lang/ua.json` | Intro headline, contact, page labels, projects label, Boy from City B. cleanup |
| `www/original.html` | EN fallback for intro headline |
| `www/lang/bundle.js` | Rebuilt |

**Not changed:** `index.html`, `services.html`, CSS.

---

## EN corrections applied

| Key | Before | After |
|-----|--------|-------|
| `original.introTitle` | The worlds we build for ourselves. | **The worlds we build.** |
| `contact.original.headline` | *(already correct)* | Interested in one of our worlds? |
| `contact.original.subline` | *(unchanged)* | Tell us which project you want to discuss. We respond within 24 hours. |

---

## UA corrections applied

| Key | Change |
|-----|--------|
| `original.introTitle` | **Світи, які ми створюємо.** |
| `contact.original.headline` | **Цікавить копродукція або ліцензування?** (removed *власний контент*) |
| `contact.original.subline` | **Розкажіть, який проєкт хочете обговорити. Ми відповідаємо протягом 24 годин.** |
| `original.pageTitle` | Власний контент → **Авторські світи — LISENBART** |
| `original.label` / `headline` | Власний контент → **Авторські світи** |
| `original.subline` | *дитячий контент* → **дитячі історії** |
| `original.projectsLabel` | Авторські проєкти → **Авторські світи** |
| `original.boyFromCityB.desc` | Removed internal production note; replaced with public copy |

---

## PL corrections applied

| Key | Change |
|-----|--------|
| `original.introTitle` | **Światy, które tworzymy.** |
| `contact.original.headline` | **Interesuje Cię koprodukcja albo licencjonowanie?** (removed *treść autorska*) |
| `contact.original.subline` | **Napisz, który projekt chcesz omówić. Odpowiadamy w ciągu 24 godzin.** |
| `original.pageTitle` | Treści autorskie → **Autorskie światy — LISENBART** |
| `original.label` / `headline` | Treści autorskie → **Autorskie światy** |
| `original.subline` | *treści dla dzieci* → **historie dla dzieci** |
| `original.projectsLabel` | Projekty autorskie → **Autorskie światy** |
| `original.boyFromCityB.desc` | Removed internal production note; replaced with public copy |

---

## Contact headline cleanup

| Language | Headline | Subline |
|----------|----------|---------|
| EN | Interested in one of our worlds? | Tell us which project you want to discuss. We respond within 24 hours. |
| UA | Цікавить копродукція або ліцензування? | Розкажіть, який проєкт хочете обговорити. Ми відповідаємо протягом 24 годин. |
| PL | Interesuje Cię koprodukcja albo licencjonowanie? | Napisz, który projekt chcesz omówić. Odpowiadamy w ciągu 24 godzin. |

Removed wording that implied LISENBART creates original content on demand for external partners.

---

## Internal note cleanup

Removed from PL and UA `original.boyFromCityB.desc`:

- PL: *Finalny logline, grupa wiekowa i format powinny zostać potwierdzone przed premierą publiczną.*
- UA: *Фінальні logline, цільову аудиторію та формат слід підтвердити перед публічним запуском.*

Replaced with shorter public-facing descriptions aligned with EN.

---

## Bundle rebuild status

```
node www/js/rebuild-lang-bundle.js
→ bundle.js rebuilt (118 keys × 3 langs, 99 HTML refs OK)
```

---

## Quality checklist

| # | Check | Result |
|---|-------|--------|
| 1 | EN intro: The worlds we build. | ✓ |
| 2 | UA intro: Світи, які ми створюємо. | ✓ |
| 3 | PL intro: Światy, które tworzymy. | ✓ |
| 4 | EN contact: Interested in one of our worlds? | ✓ |
| 5 | UA contact: Цікавить копродукція або ліцензування? | ✓ |
| 6 | PL contact: Interesuje Cię koprodukcja albo licencjonowanie? | ✓ |
| 7 | No власний контент / treści autorskie in contact | ✓ |
| 8 | No “for ourselves” in EN/UA/PL | ✓ |
| 9 | No public internal production notes | ✓ |
| 10 | Nav unchanged | ✓ |
| 11 | No Original Content / Client Work / Services / Animation on Demand on original page | ✓ |
| 12 | No public `[NEEDS CLIENT INPUT]` | ✓ |
| 13 | No missing i18n keys | ✓ |
| 14 | Language switcher (bundle intact) | ✓ |
| 15 | Bundle rebuilt | ✓ |

---

## Remaining copy risks

1. **PL/UA hero headline** still uses page title *Autorskie światy* / *Авторські світи* rather than the cinematic EN headline (*Where our own stories become animated worlds.*). Full hero localization deferred.

2. **PL/UA intro body and proof line** remain legacy copy — not aligned with latest EN rewrite. Recommend a follow-up PL/UA localization pass for intro + project cards.

3. **PL/UA project card descriptions** (except Boy from City B.) still use longer legacy partner-facing language. EN cards are shorter; PL/UA parity not in scope for this pass.

4. **Form dropdown** still includes *Co-production / Original IP* (EN) — intentional; not a contact headline issue.

5. **services.html PL/UA** still uses legacy naming (*Praca dla klientów*, *Клієнтська робота*) — out of scope; separate pass needed.
