# LISENBART — Hero & About Copy Corrections Report

**Date:** 2026-05-28  
**Task:** Apply approved Hero and About headline localization/copy corrections (EN / PL / UA).

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/en.json` | Updated `about.headline` |
| `www/lang/pl.json` | Updated `hero.headline` and `about.headline` |
| `www/lang/ua.json` | Updated `hero.headline` and `about.headline` |
| `www/lang/bundle.js` | Rebuilt after JSON changes |
| `www/index.html` | Updated EN fallback for `about.headline` |

**Not changed:** CSS, site structure, About body text, nav, contact headlines, hero sublines (already matched approved PL/UA versions), EN hero headline.

---

## EN hero / about status

| Key | Status |
|-----|--------|
| `hero.headline` | Unchanged — *Endless stories. Different worlds. One language.* |
| `hero.subline` | Unchanged — approved EN subline |
| `about.headline` | **Updated** → *We shape worlds through movement, rhythm and visual craft.* |
| `about.body` | Unchanged — proof facts remain embedded (2006, 1991, 1,000+, 11 awards, 45 selections) |

---

## UA corrections

| Key | Before | After |
|-----|--------|-------|
| `hero.headline` | …Різноманітні світи. **Одна мова.** | …Різноманітні світи. **Універсальна мова.** |
| `hero.subline` | *(already approved)* | No change |
| `about.headline` | **Одна студія. Одна мова анімації.** | **Ми створюємо світи, які рухаються, говорять і запам'ятовуються.** |
| `about.body` | Unchanged | — |

---

## PL corrections

| Key | Before | After |
|-----|--------|-------|
| `hero.headline` | …Różnorodne światy. **Jeden język.** | …Różnorodne światy. **Uniwersalny język.** |
| `hero.subline` | *(already approved)* | No change |
| `about.headline` | **Jedno studio. Jeden język animacji.** | **Tworzymy światy, które poruszają się, przemawiają i zostają w pamięci.** |
| `about.body` | Unchanged | — |

---

## Bundle rebuild status

```
node www/js/rebuild-lang-bundle.js
→ bundle.js rebuilt (118 keys × 3 langs, 99 HTML refs OK)
```

No missing i18n keys reported.

---

## Quality checklist

| # | Check | Result |
|---|-------|--------|
| 1 | EN hero headline exact | ✓ *Endless stories. Different worlds. One language.* |
| 2 | UA hero headline exact | ✓ *Нескінченні історії. Різноманітні світи. Універсальна мова.* |
| 3 | PL hero headline exact | ✓ *Niekończące się historie. Różnorodne światy. Uniwersalny język.* |
| 4 | EN about headline exact | ✓ *We shape worlds through movement, rhythm and visual craft.* |
| 5 | UA about headline exact | ✓ *Ми створюємо світи, які рухаються, говорять і запам'ятовуються.* |
| 6 | PL about headline exact | ✓ *Tworzymy światy, które poruszają się, przemawiają i zostają w pamięci.* |
| 7 | Hero sublines match approved versions | ✓ EN / PL / UA |
| 8 | No separate stats block on homepage | ✓ No `.about-stats` in `index.html` |
| 9 | Language switcher (EN / PL / UA) | ✓ Bundle keys intact |
| 10 | No missing i18n keys | ✓ Rebuild validation OK |
| 11 | No public `[NEEDS CLIENT INPUT]` | ✓ None in `www/` |
| 12 | No CSS regression | ✓ No CSS changes made |

**Preserved (per scope):** Nav labels, contact headlines, About body, doors, no stats block re-added.

---

## Layout concerns

None expected. Only headline strings changed; no CSS or structural edits. About section remains single-column (`about-grid--single`) with multiline body from prior stats-removal pass.

---

## Follow-up

Optional browser QA at PL/UA to confirm longer About headlines wrap cleanly on mobile. No copy or layout changes required unless visual review finds overflow.
