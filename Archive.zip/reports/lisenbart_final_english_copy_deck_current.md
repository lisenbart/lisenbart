# LISENBART Final English Copy Deck — Current

## Navigation

**Brand**

LISENBART

**Primary**

Original Content  
Client Work

**Secondary**

About  
Contact

**CTA**

Let's talk →

**Mobile menu**

Close

---

## Home

### Hero

Animation Studio

**Headline**

Original content. Client work. One animation studio.

**Subline**

LISENBART creates award-winning animated films and original IP, and brings the same craft to animation for brands, agencies and mobile game studios.

**Location**

Canada · Ukraine · Poland

**Scroll**

↓ Explore

### Doors

**Door 1 — Original Content**

Original Content

Films, children's content and original animated worlds developed inside LISENBART.

Explore original work →

Visual coming soon

**Door 2 — Client Work**

Client Work

Commercial animation, brand films, explainers, motion design and mobile game cinematics produced for clients.

Start a project →

Visual coming soon

### Clients

Trusted by

Playtika  
SuperPlay  
Client logo

### About

About

**Headline**

Original work sharpens the craft. Client work puts it into production.

**Body**

LISENBART is an animation studio founded in 2006 by Dmytro Lisenbart, an animation director and producer working in animation since 1991. We create original animated films and IP, and we produce animation for brands, agencies and mobile game studios. Our short film Unnecessary Things received 11 international awards across 45 festival selections. The studio has also delivered 1,000+ commercial animation projects. The same directing, timing and visual craft behind our original work goes into the animation we make for clients.

**Core line**

Award-winning craft, applied to real production.

**Stats**

Since 2006 — Studio founded  
1,000+ — Projects delivered  
11 — International awards  
Since 1991 — Directing since

### Contact

**Headline**

Tell us what you need to animate.

**Subline**

Send us a short brief. We respond within 24 hours.

**Email**

info@lisenbart.com

**Location**

Canada · Ukraine · Poland

**Social**

Vimeo  
LinkedIn  
Facebook  
YouTube

---

## Original Content

### Hero

Original Content

**Headline**

Original Content

**Subline**

Animated films, children's content and original IP developed inside LISENBART.

### Intro

**Headline**

Animated worlds we build ourselves.

**Body**

Original content is where we develop the stories, characters and visual language behind LISENBART. These projects include award-winning short films, children's content and IP in development for co-production, licensing and broadcast opportunities.

**Proof line**

The craft behind our original work is the same craft we bring to client animation.

**Section label**

Original projects

### Project Cards

**Unnecessary Things**

Award-winning animated short

Unnecessary Things

An award-winning animated short with 11 international awards and 45 festival selections — a clear proof of our directing, timing and visual craft.

Project visual

**SmartBabies**

In Development

SmartBabies

An educational animation brand for toddlers and preschool children, built around songs, simple learning patterns and bright character-led worlds. Designed for scalable digital formats, music clips, learning content and future licensing.

Project visual

**BibiBoo**

In Development

BibiBoo

A warm preschool animated world led by Bibi and Boo — two friendly characters built for play, music, discovery and emotional learning. Designed for short episodes, songs and digital-first growth.

Project visual

**Pershosvit**

Seeking Co-Production

Pershosvit

A Ukrainian children's learning universe with songs, early education, bright characters and family-safe storytelling. Built with room for international adaptation across animation, books, music and educational products.

Project visual

**The Last Cossack**

Seeking Co-Production

The Last Cossack

An animated fantasy adventure rooted in Ukrainian myth, history and heroic storytelling. A distinctive Eastern European IP with cinematic scale, strong visual identity and international genre potential.

Project visual

**Boy from City B. / Tears of God**

Seeking Co-Production

Boy from City B. / Tears of God

An author-driven animated project designed for emotional storytelling, festival potential and a distinctive visual world. Final logline, target audience and format should be confirmed before public launch.

Project visual

### Contact

**Headline**

Interested in original content, co-production or licensing?

**Subline**

Tell us which project you want to discuss. We respond within 24 hours.

**Email**

info@lisenbart.com

**Location**

Canada · Ukraine · Poland

**Social**

Vimeo  
LinkedIn  
Facebook  
YouTube

---

## Client Work / Animation on Demand

### Hero

Animation on Demand

**Headline**

Animation on Demand

**Subline**

Commercial animation, brand films, explainers, motion design and mobile game cinematics produced for brands, agencies and game studios.

### Intro

**Headline**

Award-winning craft for client production.

**Body**

We produce animation for clients who need clear storytelling, strong visual direction and reliable delivery. From brand films and explainers to mobile game cinematics and marketing assets, our work is built for real briefs, real deadlines and real audiences.

### For Brands & Agencies

**Headline**

For Brands & Agencies

**Body**

We help agencies and brands turn briefs into animation that explains, promotes and supports the campaign. Our work includes brand films, explainers, social content, pitch videos and motion assets designed for clarity, timing and campaign use.

**Tags**

Brand Films · Explainer Videos · Motion Design · Social Animation · Pitch Videos · Live Action + Animation · 2D Animation · 3D Animation

### For Mobile Game Studios

**Headline**

For Mobile Game Studios

**Body**

We create mobile game cinematics, trailers and marketing animation for studios that need strong character moments, clear emotional hooks and production-ready delivery. Our experience with Playtika and SuperPlay helps us understand the speed and iteration cycles of mobile game production.

**Tags**

Mobile Game Cinematics · Game Trailers · In-Game Cutscenes · Character Animation · Marketing Packs · UI/UX Animation · 2D Animation · 3D Animation

### Approach

**Headline**

Human direction. AI speed.

**Body**

Creative decisions stay with people. AI helps us explore, iterate and produce faster, but the final direction, rhythm, performance and visual choices remain human-led. This lets us support real production timelines without turning the work into generic automated output.

### Selected Client Work

Selected Client Work

**Playtika / SuperPlay**

Mobile Game Cinematics

Playtika / SuperPlay

Mobile game cinematics and animation for Playtika and SuperPlay — built for fast production cycles and player-facing marketing.

Project visual

**Commercial Animation**

Brands & Agencies

Commercial Animation

Brand films, explainers and motion assets for campaigns that need clarity, speed and visual craft.

Project visual

### Contact

**Headline**

Ready to start a client animation project?

**Subline**

Send us the brief, deadline, format and available assets. We respond within 24 hours.

**Email**

info@lisenbart.com

**Location**

Canada · Ukraine · Poland

**Social**

Vimeo  
LinkedIn  
Facebook  
YouTube

---

## 404

404

**Headline**

This frame is missing.

**Body**

The page you are looking for does not exist or has moved.

**CTA**

Back to home →

---

## Form Microcopy

**Fields**

Name  
Company  
Email  
What do you need?  
Message

**Dropdown options**

Brand animation  
Mobile game cinematics  
Explainer video  
Motion design  
Other

**Message placeholder**

Tell us about the project, deadline, format and available assets.

**Submit**

Send →

**Success**

Thank you — we received your message and will get back to you within 24 hours.

**Error**

Something went wrong. Please email us directly at info@lisenbart.com.
