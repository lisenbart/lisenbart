# LISENBART — Commercial Animation Copy Rewrite Report

**Date:** 2026-05-28  
**Scope:** English copy rewrite for `services.html` only.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/en.json` | Rewrote `services.*` keys and `contact.services.headline` |
| `www/services.html` | Updated meta description and all visible EN fallback text |
| `www/lang/bundle.js` | Rebuilt after JSON changes |

**Not changed:** `index.html`, `original.html`, `pl.json`, `ua.json`, CSS.

---

## Hero copy updated

| Key | New copy |
|-----|----------|
| `services.label` | Commercial Animation *(unchanged)* |
| `services.headline` | Animation for brands, agencies and mobile games. |
| `services.subline` | Brand films, explainers, motion design and mobile game cinematics — shaped through the same language of movement, rhythm and visual craft behind our original worlds. |
| `services.metaDescription` | Brand films, explainers, motion design and mobile game cinematics shaped through movement, rhythm and visual craft. |

---

## Intro copy updated

| Key | New copy |
|-----|----------|
| `services.introTitle` | When an idea needs to move. |
| `services.introBody` | Some stories begin as films. Others begin as a product, a campaign, a pitch or a game launch. We help brands, agencies and mobile game studios turn those ideas into animation with clarity, rhythm and visual force. Commercial animation should not feel generic. It should carry a message, a mood and a reason to be remembered. |

Bridge line appended to intro body (no separate layout field on page).

---

## Brands & Agencies copy updated

**Headline:** For Brands & Agencies *(unchanged)*

**Body:** We create animation for campaigns that need to explain, present, persuade or stay in memory. From brand films and explainers to pitch videos, social content and motion assets, we shape the message through movement, timing and visual craft.

**Tags:** unchanged

---

## Mobile Game Studios copy updated

**Headline:** For Mobile Game Studios *(unchanged)*

**Body:** Mobile games need to be felt quickly. We create cinematics, trailers, cutscenes and marketing animation that help players understand the world, feel the character and remember the game. Our work for Playtika and SuperPlay reflects the speed and iteration rhythm of mobile game production.

**Tags:** unchanged

---

## Approach copy updated

| Key | New copy |
|-----|----------|
| `services.approachTitle` | Human direction. Faster production. |
| `services.approachBody` | Creative decisions stay human: story, rhythm, performance, composition and final visual taste. AI can help us explore, iterate and move faster, but it does not replace direction. The goal is simple: more room for ideas, fewer slow production loops, and animation that still feels crafted. |

Removed defensive “generic automated output” phrasing.

---

## Selected work copy updated

| Key | New copy |
|-----|----------|
| `services.workLabel` | Selected Commercial Work |
| `services.case1Desc` | Cinematics and animation for mobile game leaders — built around character moments, fast iteration and player-facing marketing. |
| `services.case2Title` | Brand Films & Motion Assets |
| `services.case2Desc` | Commercial animation for campaigns, pitches and digital channels — designed to make ideas clearer, sharper and easier to remember. |

Case 1 title/category unchanged (Playtika / SuperPlay · Mobile Game Cinematics).

---

## Contact copy updated

| Key | New copy |
|-----|----------|
| `contact.services.headline` | Let's make your idea move. |
| `contact.services.subline` | Send us the brief, deadline, format and available assets. We respond within 24 hours. *(unchanged)* |

Form microcopy unchanged.

---

## Bundle rebuild status

```
node www/js/rebuild-lang-bundle.js
→ bundle.js rebuilt (118 keys × 3 langs, 99 HTML refs OK)
```

---

## Quality checklist

| # | Check | Result |
|---|-------|--------|
| 1 | Hero label: Commercial Animation | ✓ |
| 2 | Hero headline: Animation for brands, agencies and mobile games. | ✓ |
| 3 | Hero subline (approved version) | ✓ |
| 4 | Intro headline: When an idea needs to move. | ✓ |
| 5 | Brands & Agencies body updated | ✓ |
| 6 | Mobile Game Studios body + Playtika/SuperPlay | ✓ |
| 7 | Approach headline: Human direction. Faster production. | ✓ |
| 8 | Approach body less technical/defensive | ✓ |
| 9 | Selected work: Selected Commercial Work | ✓ |
| 10 | Case 2 title: Brand Films & Motion Assets | ✓ |
| 11 | Case 2 no longer “Commercial Animation” placeholder | ✓ |
| 12 | Contact: Let's make your idea move. | ✓ |
| 13 | No old labels (Original Content, Client Work, Services, Animation on Demand) | ✓ |
| 14 | Nav unchanged | ✓ |
| 15 | No public `[NEEDS CLIENT INPUT]` | ✓ |
| 16 | No missing i18n keys | ✓ |
| 17 | Language switcher (bundle intact) | ✓ |
| 18 | Bundle rebuilt | ✓ |

---

## Remaining risks & recommendations

1. **PL/UA not updated** — Switching language on `services.html` still shows legacy copy (e.g. *Praca dla klientów*, *Клієнтська робота*, old intro/approach). Schedule PL/UA localization when EN is approved.

2. **Homepage doors card** — `doors.services.desc` on `index.html` may still use older phrasing. Out of scope; align in a future homepage sync if desired.

3. **Case 1 description** — No longer names Playtika/SuperPlay in body text (names remain in card title). Intentional per approved copy; verify client naming preference if needed.

4. **Visual QA** — Longer intro body on mobile; no CSS changes made. Check line breaks if needed.
