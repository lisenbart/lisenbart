# LISENBART Copy Fixes v1 — Applied Report

**Date:** 2026-05-28  
**Scope:** Three surgical English copy/form fixes. No CSS or redesign. PL/UA parity keys only.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/en.json` | `hero.subline` updated |
| `www/lang/pl.json` | `contact.needOptions.coproduction` label aligned |
| `www/lang/ua.json` | `contact.needOptions.coproduction` label aligned |
| `www/lang/bundle.js` | Rebuilt |
| `www/index.html` | Hero subline fallback; removed `about.coreLine`; added coproduction dropdown option |
| `www/original.html` | Added coproduction dropdown option (first) |
| `www/services.html` | Added coproduction dropdown option (first) |

**Not changed:** CSS, PL/UA body copy, `about.coreLine` key in JSON (retained unused for key parity).

---

## Hero subline update

**Before (en.json):**  
We develop original animated worlds inside the studio — and bring that same craft to brands, agencies and mobile games.

**After (en.json + index.html fallback):**  
LISENBART creates original animated worlds and brings the same language of movement, rhythm and visual craft to brands, agencies and mobile games.

**Hero headline unchanged:**  
Endless stories. Different worlds. One language.

---

## About coreLine removal

Removed from `www/index.html`:

```html
<p class="about-grid__body about-grid__body--multiline" data-i18n="about.coreLine">One language, shaped for many worlds.</p>
```

The About section now ends with the main body copy. `about.coreLine` remains in lang JSON but is not referenced in HTML.

---

## Contact dropdown update

Added first option on all contact forms (`index.html`, `original.html`, `services.html`):

| Attribute | Value |
|-----------|--------|
| `value` | `coproduction` |
| i18n key | `contact.needOptions.coproduction` |
| EN label | Co-production / Original IP |

**Remaining options (order unchanged after new first option):**

1. Co-production / Original IP  
2. Brand animation  
3. Mobile game cinematics  
4. Explainer video  
5. Motion design  
6. Other  

**PL parity:** Koprodukcja / autorskie IP  
**UA parity:** Копродукція / власний IP  

---

## Bundle rebuild status

```bash
node www/js/rebuild-lang-bundle.js
```

**Result:** Success  
**Key parity:** EN / PL / UA — 0 missing, 0 extra keys

---

## Quality checklist

| # | Check | Result |
|---|-------|--------|
| 1 | Hero headline: Endless stories. Different worlds. One language. | ✅ |
| 2 | Hero subline matches approved shortened copy exactly | ✅ |
| 3 | `about.coreLine` not visible on homepage | ✅ |
| 4 | First dropdown option: Co-production / Original IP | ✅ |
| 5 | Existing five options remain after coproduction | ✅ |
| 6 | Language switcher works (key parity intact) | ✅ |
| 7 | No missing i18n keys | ✅ |
| 8 | No CSS changes | ✅ |
| 9 | No public [NEEDS CLIENT INPUT] | ✅ |

---

## Notes

- Coproduction option added to `original.html` and `services.html` as well as home, so all contact forms stay consistent.
- `about.coreLine` can be removed from JSON in a future cleanup pass if desired; kept now to avoid unnecessary key churn across PL/UA.
