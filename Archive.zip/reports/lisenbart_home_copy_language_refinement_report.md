# LISENBART Home Copy & Language Refinement Report

**Date:** 2026-05-28  
**Scope:** English copy refinement to approved central brand idea. No visual redesign. PL/UA not rewritten.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/en.json` | Full English copy update (source of truth) |
| `www/lang/bundle.js` | Rebuilt from JSON |
| `www/index.html` | Nav, hero, doors, about, contact fallbacks; meta title/description |
| `www/original.html` | Nav, hero, intro, projects label, contact fallbacks; meta |
| `www/services.html` | Nav, hero, work label, contact fallbacks; meta/title |
| `www/404.html` | Nav fallbacks |

**Not changed:** `www/lang/pl.json`, `www/lang/ua.json` (keys unchanged; old translations remain until dedicated pass)

---

## Exact English copy updated

### Central brand formula (homepage hero)

**Headline:** Endless stories. Different worlds. One language.

**Subline:** LISENBART creates original animated films and IP, and brings the same language of movement, rhythm and visual craft to commercial animation for brands, agencies and mobile games.

### Navigation

Original Worlds  
Commercial Animation  
About  
Contact  
Let's talk →

### Homepage doors

**Door 1 — Original Worlds**  
Animated films, children's stories and original IP developed inside LISENBART.  
Explore original worlds →

**Door 2 — Commercial Animation**  
Brand films, explainers, motion design and mobile game cinematics shaped through movement, rhythm and visual craft.  
Start a project →

### Homepage about

**Headline:** One studio. One language of animation.

**Body:** LISENBART works across original films, animated IP and commercial production. Some stories begin inside the studio. Others come from a brand, an agency or a game world that needs to move, speak and be remembered. What connects them is not format. It is language — movement, rhythm, image, character and visual craft. Founded in 2006 by animation director and producer Dmytro Lisenbart, whose work in animation began in 1991, the studio has delivered 1,000+ commercial animation projects. Its short film Unnecessary Things received 11 international awards across 45 festival selections. Different worlds need different stories. We give them one language.

**Core line:** One language, shaped for many worlds.

**Stat 4 label:** Animation direction (was “Directing since”)

### Homepage contact

**Headline:** Let's give your world a language.

**Subline:** Tell us what you want to create. We respond within 24 hours.

### Meta (home)

**Title:** LISENBART — Original Worlds & Commercial Animation

**Description:** Animation studio creating original films and IP, and shaping commercial animation for brands, agencies and mobile games through one language of movement, rhythm and visual craft.

---

## Navigation changes

| Before | After |
|--------|-------|
| Original Content | **Original Worlds** |
| Client Work | **Commercial Animation** |
| About | About (unchanged) |
| Contact | Contact (unchanged) |
| Let's talk → | Let's talk → (unchanged) |

Applied on: `index.html`, `original.html`, `services.html`, `404.html` (header + mobile nav).

---

## Homepage changes

- Hero headline and subline replaced with approved brand formula
- Door labels: Original Worlds / Commercial Animation
- Door descriptions and Original Worlds CTA updated
- About section fully rewritten (headline, body, core line)
- Contact headline and subline updated
- Meta title and description aligned with new naming

**Unchanged per brief:** Clients (“Trusted by”), form fields, dropdown options, success/error messages, location, email.

---

## Original Worlds page changes

| Element | Before | After |
|---------|--------|-------|
| Page title | Original Content — LISENBART | Original Worlds — LISENBART |
| H1 | Original Content | Original Worlds |
| Subline | …children's content… | Animated films, children's stories and IP developed inside LISENBART. |
| Intro headline | Animated worlds we build ourselves. | Worlds born inside the studio. |
| Intro body | Original content is where… | Original worlds are where LISENBART develops… |
| Proof line | …craft we bring to client animation. | The same language of movement, rhythm and visual craft also shapes our commercial animation. |
| Projects label | Original projects | Original worlds |
| Contact headline | …original content… | Interested in original worlds, co-production or licensing? |

Project card descriptions unchanged.

---

## Commercial Animation page changes

| Element | Before | After |
|---------|--------|-------|
| Page title | Client Work — LISENBART | Commercial Animation — LISENBART |
| Section label | Animation on Demand | Commercial Animation |
| H1 | Animation on Demand | Animation for Brands, Agencies and Games |
| Subline | …produced for brands… | …created with the same language of movement, rhythm and visual craft we bring to our original worlds. |
| Work section label | Selected Client Work | Selected work |
| Contact headline | Ready to start a client animation project? | Ready to start a commercial animation project? |

Intro blocks, approach, cases, and form unchanged (except nav).

---

## PL/UA structure sync

- **No PL/UA string updates** in this pass (per brief).
- **Key parity verified:** EN / PL / UA — 0 missing keys, 0 extra keys.
- **Switcher behavior:** PL and UA will show previous translations for updated strings until a translation pass runs. Nav will still display legacy PL/UA labels (e.g. “Treści autorskie”, “Praca dla klientów”) while English shows “Original Worlds” / “Commercial Animation”.

---

## Quality checklist result

| # | Check | Result |
|---|-------|--------|
| 1 | Hero: Endless stories. Different worlds. One language. | ✅ |
| 2 | Hero subline matches approved copy exactly | ✅ |
| 3 | Nav: Original Worlds / Commercial Animation / About / Contact / Let's talk → | ✅ |
| 4 | Contact headline: Let's give your world a language. | ✅ |
| 5 | No public “Client Work” nav label | ✅ |
| 6 | No public “Services” nav label | ✅ |
| 7 | No public “Original Content” headline | ✅ |
| 8 | No old three-pillar top-level language | ✅ |
| 9 | No visible [NEEDS CLIENT INPUT] | ✅ |
| 10 | No invented claims or facts | ✅ |
| 11 | EN/PL/UA key parity; switcher functional | ✅ |

---

## Remaining risks and recommendations

1. **PL/UA drift** — English now uses “Original Worlds” / “Commercial Animation” / “one language” framing; PL and UA still carry prior copy. Schedule a translation pass when English is locked.

2. **Internal docs** — `www/README.md` still references “Original Content / Animation on Demand” in the page table. Update when convenient (not user-facing).

3. **Services intro body** — Still uses “client production” phrasing in `services.introTitle` / `services.introBody`. Not in this pass scope; consider aligning to “one language” tone in a follow-up.

4. **Long about paragraph** — About body is one block in HTML; multiple logical paragraphs render as continuous text. Optional future enhancement: split into `<p>` elements without changing visual system.

5. **Transition keys** — Updated in EN for legacy redirect copy (`transition.*`). No live transition pages; low risk.

6. **Meta / SEO** — New page titles and descriptions applied in EN. Confirm analytics/search console after deploy if URLs are indexed under old titles.

---

## Rebuild command

After any future JSON edit:

```bash
node www/js/rebuild-lang-bundle.js
```
