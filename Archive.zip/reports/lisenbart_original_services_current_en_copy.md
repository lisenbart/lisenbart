# LISENBART — Original Worlds & Commercial Animation Current EN Copy

Extracted from `original.html` and `services.html` (English, user-visible copy only).  
Source: HTML fallbacks / `en.json` — identical where both exist.

---

## Original Worlds page

### Meta title / description

**Title:** Original Worlds — LISENBART

**Description:** Award-winning animated films, children's stories and original IP developed inside LISENBART.

### Navigation labels

**Logo:** LISENBART

**Primary nav:** Original Worlds · Commercial Animation

**Secondary nav:** About · Contact

**CTA:** Let's talk →

**Mobile:** Close

**Language selector:** 🇬🇧 EN · 🇵🇱 PL · 🇺🇦 UA

**Menu button (visible label):** Open menu

### Hero

**Label:** Original Worlds

**Headline:** Original Worlds

**Subline:** Animated films, children's stories and IP developed inside LISENBART.

### Intro

**Headline:** Worlds born inside the studio.

**Body:** Original worlds are where LISENBART develops its stories, characters and visual language. These projects include award-winning animated films, children's stories and IP in development for co-production, licensing and broadcast opportunities.

**Proof line:** The same language of movement, rhythm and visual craft also shapes our commercial animation.

### Project cards

**Section label:** Original worlds

**Media placeholder (all cards):** Project visual

#### Unnecessary Things

**Status:** Award-winning animated short

**Title:** Unnecessary Things

**Description:** An award-winning animated short with 11 international awards and 45 festival selections — a clear proof of our directing, timing and visual craft.

#### SmartBabies

**Status:** In Development

**Title:** SmartBabies

**Description:** An educational animation brand for toddlers and preschool children, built around songs, simple learning patterns and bright character-led worlds. Designed for scalable digital formats, music clips, learning content and future licensing.

#### BibiBoo

**Status:** In Development

**Title:** BibiBoo

**Description:** A warm preschool animated world led by Bibi and Boo — two friendly characters built for play, music, discovery and emotional learning. Designed for short episodes, songs and digital-first growth.

#### Pershosvit

**Status:** Seeking Co-Production

**Title:** Pershosvit

**Description:** A Ukrainian children's learning universe with songs, early education, bright characters and family-safe storytelling. Built with room for international adaptation across animation, books, music and educational products.

#### The Last Cossack

**Status:** Seeking Co-Production

**Title:** The Last Cossack

**Description:** An animated fantasy adventure rooted in Ukrainian myth, history and heroic storytelling. A distinctive Eastern European IP with cinematic scale, strong visual identity and international genre potential.

#### Boy from City B. / Tears of God

**Status:** Seeking Co-Production

**Title:** Boy from City B. / Tears of God

**Description:** An author-driven animated project designed for emotional storytelling, festival potential and a distinctive visual world. Final logline, target audience and format should be confirmed before public launch.

### Contact

**Headline:** Interested in original worlds, co-production or licensing?

**Subline:** Tell us which project you want to discuss. We respond within 24 hours.

**Email:** info@lisenbart.com

**Location:** Canada · Ukraine · Poland

**Social links:** Vimeo · LinkedIn · Facebook · YouTube

### Form microcopy if page-specific

**Contact headline / subline:** *(page-specific — see above)*

**Form fields (shared):**

- **Name**
- **Company**
- **Email**
- **What do you need?**
  - Co-production / Original IP
  - Brand animation
  - Mobile game cinematics
  - Explainer video
  - Motion design
  - Other
- **Message** — placeholder: *Tell us about the project, deadline, format and available assets.*
- **Submit:** Send →

---

## Commercial Animation page

### Meta title / description

**Title:** Commercial Animation — LISENBART

**Description:** Commercial animation, brand films, explainers, motion design and mobile game cinematics for brands, agencies and mobile games.

### Navigation labels

**Logo:** LISENBART

**Primary nav:** Original Worlds · Commercial Animation

**Secondary nav:** About · Contact

**CTA:** Let's talk →

**Mobile:** Close

**Language selector:** 🇬🇧 EN · 🇵🇱 PL · 🇺🇦 UA

**Menu button (visible label):** Open menu

### Hero

**Label:** Commercial Animation

**Headline:** Animation for Brands, Agencies and Games

**Subline:** Commercial animation, brand films, explainers, motion design and mobile game cinematics — created with the same language of movement, rhythm and visual craft we bring to our original worlds.

### Intro

**Headline:** Award-winning craft for client production.

**Body:** We produce animation for clients who need clear storytelling, strong visual direction and reliable delivery. From brand films and explainers to mobile game cinematics and marketing assets, our work is built for real briefs, real deadlines and real audiences.

### For Brands & Agencies

**Headline:** For Brands & Agencies

**Body:** We help agencies and brands turn briefs into animation that explains, promotes and supports the campaign. Our work includes brand films, explainers, social content, pitch videos and motion assets designed for clarity, timing and campaign use.

**Tags:** Brand Films · Explainer Videos · Motion Design · Social Animation · Pitch Videos · Live Action + Animation · 2D Animation · 3D Animation

### For Mobile Game Studios

**Headline:** For Mobile Game Studios

**Body:** We create mobile game cinematics, trailers and marketing animation for studios that need strong character moments, clear emotional hooks and production-ready delivery. Our experience with Playtika and SuperPlay helps us understand the speed and iteration cycles of mobile game production.

**Tags:** Mobile Game Cinematics · Game Trailers · In-Game Cutscenes · Character Animation · Marketing Packs · UI/UX Animation · 2D Animation · 3D Animation

### Approach

**Headline:** Human direction. AI speed.

**Body:** Creative decisions stay with people. AI helps us explore, iterate and produce faster, but the final direction, rhythm, performance and visual choices remain human-led. This lets us support real production timelines without turning the work into generic automated output.

### Selected Client Work

**Section label:** Selected work

**Media placeholder (all cards):** Project visual

#### Playtika / SuperPlay

**Category:** Mobile Game Cinematics

**Title:** Playtika / SuperPlay

**Description:** Mobile game cinematics and animation for Playtika and SuperPlay — built for fast production cycles and player-facing marketing.

#### Commercial Animation

**Category:** Brands & Agencies

**Title:** Commercial Animation

**Description:** Brand films, explainers and motion assets for campaigns that need clarity, speed and visual craft.

### Contact

**Headline:** Ready to start a commercial animation project?

**Subline:** Send us the brief, deadline, format and available assets. We respond within 24 hours.

**Email:** info@lisenbart.com

**Location:** Canada · Ukraine · Poland

**Social links:** Vimeo · LinkedIn · Facebook · YouTube

### Form microcopy if page-specific

**Contact headline / subline:** *(page-specific — see above)*

**Form fields (shared):**

- **Name**
- **Company**
- **Email**
- **What do you need?**
  - Co-production / Original IP
  - Brand animation
  - Mobile game cinematics
  - Explainer video
  - Motion design
  - Other
- **Message** — placeholder: *Tell us about the project, deadline, format and available assets.*
- **Submit:** Send →

---

## Potential naming issues

| Location | Copy | Note |
|----------|------|------|
| Original Worlds — project section label | **Original worlds** | Lowercase *worlds* — inconsistent with nav/hero **Original Worlds** |
| Original Worlds — hero | **Original Worlds** (label + headline) | Same phrase repeated twice in hero block |
| Commercial Animation — intro headline | **Award-winning craft for client production.** | Uses *client production* — older agency framing vs current **Commercial Animation** pillar naming |
| Commercial Animation — intro body | *We produce animation for **clients** who need…* | *Clients* terminology — may conflict with refined brand language |
| Commercial Animation — work section label | **Selected work** | Generic label; not **Selected Client Work** (legacy naming not present, but section name is broad) |
| Commercial Animation — work card | **Title: Commercial Animation** | Category name reused as project title — reads like a placeholder, not a named case |
| Original Worlds — Boy from City B. card | *Final logline, target audience and format should be confirmed before public launch.* | Internal/production note visible on the public page |
| Both pages — footer | **© 2026 LISENBART** | Visible on page but outside main content structure |

**Not found on these pages:** Original Content · Client Work (nav) · Services · Animation on Demand
