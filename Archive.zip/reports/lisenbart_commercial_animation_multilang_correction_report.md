# LISENBART — Commercial Animation Multilang Correction Report

**Date:** 2026-05-28  
**Scope:** EN / UA / PL copy correction for `services.html` based on owner-revised Ukrainian direction.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/en.json` | Adapted `services.*` and `contact.services.*` to simplified commercial direction |
| `www/lang/ua.json` | Applied owner-approved UA copy; typo fix *ітерувати*; form game option label |
| `www/lang/pl.json` | Adapted PL copy to match revised UA logic |
| `www/services.html` | Updated EN fallback text |
| `www/lang/bundle.js` | Rebuilt |

**Not changed:** `index.html`, `original.html`, CSS, shared form fields (except UA dropdown game label).

---

## UA corrections applied

Full `services.*` block rewritten per owner-approved strings:

- Page/meta: **Комерційна анімація**
- Hero: clearer commercial subline without “visual craft” overload
- Intro: **Коли ідея має оживати.** + bridge appended to body
- Brands & Agencies / Mobile Game Studios: localized tags and bodies
- Approach: **Професійна режисура. Швидше виробництво.** with **ітерувати** (not *ітегрувати*)
- Selected work: **Вибрані комерційні роботи**; case titles generalized (*Мобільні ігри та паблішери*, *відомі ігрові бренди*)
- Contact: **Допоможемо вашій ідеї ожити.**

Removed legacy naming: *Клієнтська робота*, *Анімація на замовлення*, Playtika/SuperPlay in page body.

`contact.needOptions.game`: **Сінематики для мобільних ігор**

---

## EN adaptation applied

Aligned with simplified UA direction:

| Area | Key change |
|------|------------|
| Meta / subline | Direct commercial offer; no “same language behind original worlds” |
| Intro | *When an idea needs to come alive.*; bridge uses *look generic* |
| Games body | *known game brands* instead of Playtika/SuperPlay |
| Approach | *Professional direction. Faster production.*; *made by hand* |
| Case 1 | *Mobile Games & Publishers* |
| Contact | *Let's help your idea come alive.* |

---

## PL adaptation applied

Natural PL adaptation (not mechanical translation):

| Area | Key change |
|------|------------|
| Page/meta | **Animacja komercyjna** (not *Praca dla klientów* / *Animacja na zamówienie*) |
| Intro | *Kiedy idea ma ożyć.* |
| Games body | *znanych marek gier* |
| Approach | *Profesjonalna reżyseria. Szybsza produkcja.*; *zrobiona ludzką ręką* |
| Work label | *Wybrane realizacje komercyjne* |
| Case 1 | *Gry mobilne i publisherzy* |
| Contact | *Pomóżmy Twojej idei ożyć.* |

Localized PL tags (not English tag strings).

---

## Contact headline cleanup

| Lang | Headline |
|------|----------|
| EN | Let's help your idea come alive. |
| UA | Допоможемо вашій ідеї ожити. |
| PL | Pomóżmy Twojej idei ożyć. |

No *власний контент* / *treści autorskie* in contact CTAs.

---

## Bundle rebuild status

```
node www/js/rebuild-lang-bundle.js
→ bundle.js rebuilt (118 keys × 3 langs, 99 HTML refs OK)
```

---

## Quality checklist

| # | Check | Result |
|---|-------|--------|
| 1 | EN / UA / PL follow revised simpler commercial direction | ✓ |
| 2 | UA matches owner-approved strings; *ітерувати* correct | ✓ |
| 3 | EN adapted to simplified UA logic | ✓ |
| 4 | PL adapted naturally | ✓ |
| 5 | No Original Content / Client Work / Services / Animation on Demand on page | ✓ |
| 6 | Nav unchanged (EN / UA / PL) | ✓ |
| 7 | No public `[NEEDS CLIENT INPUT]` | ✓ |
| 8 | No missing i18n keys | ✓ |
| 9 | Language switcher (bundle intact) | ✓ |
| 10 | Bundle rebuilt | ✓ |

---

## Localization risks & layout concerns

1. **UA apostrophe** — `запам'ятатися` uses straight apostrophe in JSON; renders correctly in browser.

2. **Longer PL/UA tag lines** — Localized tag strings may wrap on narrow viewports; no CSS changes made.

3. **Playtika on homepage only** — `clients.logo1` on `index.html` unchanged; services page no longer names clients in body copy per brief.

4. **Homepage doors card** — `doors.services.desc` on index may still use older EN phrasing; out of scope.

5. **UA original page** — `original.proofLine` still references *клієнтську анімацію*; separate from this pass.
