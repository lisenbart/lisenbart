# LISENBART — Original Worlds Copy Rewrite Report

**Date:** 2026-05-28  
**Scope:** English copy rewrite for `original.html` only.

---

## Files changed

| File | Change |
|------|--------|
| `www/lang/en.json` | Rewrote `original.*` keys and `contact.original.headline` |
| `www/original.html` | Updated visible EN fallback text and meta description |
| `www/lang/bundle.js` | Rebuilt after JSON changes |

**Not changed:** `index.html`, `services.html`, `pl.json`, `ua.json`, CSS.

---

## Hero copy updated

| Key | New copy |
|-----|----------|
| `original.label` | Original Worlds *(unchanged)* |
| `original.headline` | Where our own stories become animated worlds. |
| `original.subline` | Films, children's stories and original IP created inside LISENBART — shaped by the same language of movement, rhythm and visual craft. |
| `original.metaDescription` | Animated films, children's stories and original IP developed inside LISENBART. |

---

## Intro copy updated

| Key | New copy |
|-----|----------|
| `original.introTitle` | The worlds we build for ourselves. |
| `original.introBody` | Original Worlds is where LISENBART develops its own stories, characters and visual language. Some projects begin as short films. Some grow into children's universes. Others are built as original IP for future co-production, licensing or broadcast partnerships. |
| `original.proofLine` | This is where our language begins — and the same craft later shapes the commercial animation we create for brands, agencies and mobile games. |

---

## Project card copy updated

| Project | Status | Description summary |
|---------|--------|---------------------|
| **Section label** | — | Original Worlds *(title case)* |
| Unnecessary Things | Award-winning animated short | 11 international awards, 45 selections — festival-recognized craft proof |
| SmartBabies | In Development | Educational brand for toddlers/preschool; digital formats, licensing |
| BibiBoo | In Development | Warm preschool world; Bibi and Boo; episodes, songs |
| Pershosvit | Seeking Co-Production | Ukrainian children's learning universe; room to grow |
| The Last Cossack | Seeking Co-Production | Ukrainian myth/history fantasy; Eastern European world |
| Boy from City B. / Tears of God | Seeking Co-Production | Author-driven; emotional/festival potential; intimate story on slate |

All cards retain **Project visual** placeholder text.

---

## Contact copy updated

| Key | New copy |
|-----|----------|
| `contact.original.headline` | Interested in one of our worlds? |
| `contact.original.subline` | Tell us which project you want to discuss. We respond within 24 hours. *(unchanged)* |

Form microcopy unchanged (shared fields, Co-production / Original IP first option, Send →).

---

## Internal/public note cleanup

**Removed from EN** (`original.boyFromCityB.desc` and HTML fallback):

> Final logline, target audience and format should be confirmed before public launch.

**Replaced with:**

> An author-driven animated project shaped for emotional storytelling, festival potential and a distinctive visual world. A more intimate original story within the LISENBART slate.

---

## Bundle rebuild status

```
node www/js/rebuild-lang-bundle.js
→ bundle.js rebuilt (118 keys × 3 langs, 99 HTML refs OK)
```

---

## Quality checklist

| # | Check | Result |
|---|-------|--------|
| 1 | Hero label: Original Worlds | ✓ |
| 2 | Hero headline: Where our own stories become animated worlds. | ✓ |
| 3 | Hero subline (approved version) | ✓ |
| 4 | Intro headline: The worlds we build for ourselves. | ✓ |
| 5 | Section label title case: Original Worlds | ✓ |
| 6 | Boy from City B. — no internal logline note (EN) | ✓ |
| 7 | Project descriptions shorter / more human | ✓ |
| 8 | Contact headline: Interested in one of our worlds? | ✓ |
| 9 | No old labels (Original Content, Client Work, Services, Animation on Demand) | ✓ |
| 10 | Nav unchanged | ✓ |
| 11 | No public `[NEEDS CLIENT INPUT]` | ✓ |
| 12 | No missing i18n keys | ✓ |
| 13 | Language switcher (bundle intact) | ✓ |
| 14 | Bundle rebuilt | ✓ |

---

## Remaining risks & recommendations

1. **PL/UA not updated** — Switching language on `original.html` still shows legacy PL/UA copy (old hero, intro, project cards). Schedule a PL/UA localization pass when EN is approved.

2. **PL/UA internal note still present** — `pl.json` and `ua.json` `original.boyFromCityB.desc` still contain production-note language about confirming logline/format before public launch. EN is clean; **minimal PL/UA cleanup recommended** before public launch if language switcher is live.

3. **Homepage doors subline** — `doors.original.desc` on `index.html` still uses older phrasing (*Animated films, children's stories and original IP developed inside LISENBART.*). Out of scope for this pass; align in a future homepage sync if desired.

4. **Meta description** — HTML `<meta>` and `original.metaDescription` now match approved copy (no “Award-winning” prefix).

5. **Visual QA** — Longer hero headline may wrap on narrow viewports; no CSS changes made. Check mobile if line breaks feel awkward.
