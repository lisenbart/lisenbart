# LISENBART.com — static site

HTML / CSS / vanilla JS. Four pages, EN source copy in `lang/en.json`.

## Local preview

```bash
cd www
python3 -m http.server 8080
```

Open http://localhost:8080

**Languages:** header dropdown — EN / PL / UA. First visit uses browser language; choice is saved in `localStorage`.

**Edit copy:** `lang/en.json`, `pl.json`, `ua.json`, then validate:

```bash
node js/rebuild-lang-bundle.js
```

At runtime the site loads **one language file** via `fetch` (`lang/{en|pl|ua}.json`, ~10 KB each). The rebuild script validates key parity, HTML `data-i18n` refs, and regenerates optional `lang/bundle.js` for legacy/offline use.

## Pages

| File | Purpose |
|------|---------|
| `index.html` | Hero, two doors (Original Worlds / Commercial Animation), clients, about, contact |
| `original.html` | Original worlds — films, children's IP, project cards, contact |
| `services.html` | Commercial animation for brands, agencies and games, contact |
| `404.html` | Not found |

Contact form is shared; headline/subline varies via `contact`, `contact.original`, `contact.services` in JSON.

## Media

Full guide: [`assets/README.md`](assets/README.md)

```
assets/hero/              — optional local showreel (hero currently uses Vimeo embed)
assets/work/<slug>/       — project covers and previews
assets/clients/           — client logos (SVG)
assets/brand/             — studio logo, favicon, OG image
assets/work/_incoming/    — drop zone before sorting into project folders
```

| Site section | Asset folder |
|--------------|--------------|
| Original Worlds projects | `assets/work/unnecessary-things/`, future IP slugs |
| Commercial case (Playtika / SuperPlay) | `assets/work/playtika-superplay/` |
| Client logos on home | `assets/clients/` |

Until media files exist, the site shows neutral text placeholders (no internal `[NEEDS CLIENT INPUT]` labels).

## Before go-live

- Wire contact form in `js/main.js` (Formspree or API endpoint)
- Add favicon and OG image under `assets/brand/`
- Replace door/case placeholders with real stills or loops

## Project docs (parent folder)

- `../docs/lisenbart_website_brief.md`
- `../docs/cursor_architecture_v1.md`
- `../reports/` — copy audits and change logs
